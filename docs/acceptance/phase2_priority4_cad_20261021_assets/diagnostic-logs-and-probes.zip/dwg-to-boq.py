"""Actual ACadSharp source + existing application/SQLite; synthetic only."""
import os,sys,json,shutil
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
sys.path.insert(0,os.environ.get('STRUCTURALPRO_SOURCE_ROOT',str(Path.cwd())))
from core.platform.application import StructuralProApp
from core.drawings.dwg_takeoff import DWGTakeoffEngine
from core.drawings.takeoff_session import DrawingTakeoffSession
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True);source=root/'synthetic-source.dwg';shutil.copy2(sys.argv[2],source)
doc=DWGTakeoffEngine().import_file(source);assert doc.conversion['decoder_version']=='3.8.0.0';line=next(e for e in doc.entities if e.entity_type=='LINE' and e.data.get('length')==5)
app=StructuralProApp(root/'db');app.create_project('مصنوعی؛ طراحی مصوب نیست','P');app.add_project_floor('P','طبقه صریح',level='L1');app.add_project_member('P','M1','L1','عضو صریح')
def measured(origin=(0,0)):
 s=DrawingTakeoffSession(str(source));i=s.add_cad_entity(doc,line.handle,'length',takeoff_code='cad-line',floor_id='L1',member_id='M1',quantity_owner='explicit sole synthetic owner',created_by='synthetic author',reference='3-4-5 independent analytic fixture',scene_origin=origin);return s,i
s,i=measured();r=app.save_drawing_takeoff_session('P',s);checks=[]
def rejected(label,fn):
 before=deepcopy(app.open_project('P'))
 try:fn()
 except (ValueError,RuntimeError):pass
 else:raise AssertionError(label+' was permitted')
 assert app.open_project('P')==before;checks.append(label)
rejected('unreviewed',lambda:app.commit_drawing_takeoff_to_boq('P',r['session_id'],[i.id],expected_session_revision=1))
s.review_cad_entity(i.id,reviewer='independent synthetic reviewer',note='5 m oracle');r=app.save_drawing_takeoff_session('P',s,session_id=r['session_id'],expected_revision=1);app.commit_drawing_takeoff_to_boq('P',r['session_id'],[i.id],expected_session_revision=2)
original=deepcopy(app.open_project('P'));assert original['boq'][0]['quantity']==5 and original['boq'][0].get('price_code') is None
app.store.close();app=StructuralProApp(root/'db');assert app.open_project('P')==original
other,j=measured((100,100));other.review_cad_entity(j.id,reviewer='independent synthetic reviewer',note='same entity with different display');rr=app.save_drawing_takeoff_session('P',other)
rejected('duplicate entity across sessions',lambda:app.commit_drawing_takeoff_to_boq('P',rr['session_id'],[j.id],expected_session_revision=1))
rejected('stale CAS',lambda:app.save_drawing_takeoff_session('P',other,session_id=rr['session_id'],expected_revision=0))
old=source.read_bytes()
try:
 source.write_bytes(old+b'\n');rejected('changed source bytes',lambda:app.commit_drawing_takeoff_to_boq('P',rr['session_id'],[j.id],expected_session_revision=1))
finally:source.write_bytes(old)
final=deepcopy(app.open_project('P'));assert final['boq']==original['boq'];assert app.store.db.execute('pragma integrity_check').fetchone()[0]=='ok';app.store.close()
(root/'project.json').write_text(json.dumps(final,ensure_ascii=False,indent=2));(root/'session.json').write_text(json.dumps(s.to_dict(),ensure_ascii=False,indent=2))
receipt={'synthetic':True,'actual_dwg_decoder':'ACadSharp 3.8.0.0','source_sha256':sha256(old).hexdigest(),'handle':line.handle,'units':doc.units,'oracle_m':'5','boq_m':'5','price_code':None,'reopen_equal':True,'sqlite_integrity':'ok','rejected_without_db_change':checks,'conversion':doc.conversion,'financial_history_unchanged':True,'exit_code':0};(root/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print(receipt)
