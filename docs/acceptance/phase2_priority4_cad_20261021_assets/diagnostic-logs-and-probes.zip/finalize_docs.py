from pathlib import Path
import json,hashlib,shutil,zipfile,gzip,subprocess,xml.etree.ElementTree as ET
root=Path.cwd(); e=Path('/tmp/p4-evidence'); a=root/'docs/acceptance/phase2_priority4_cad_20261021_assets';a.mkdir(exist_ok=True)
def copy(p,name=None):
 p=Path(p);q=a/(name or p.name);shutil.copy2(p,q);return q.name
for n in ['full-final.log','targeted-final-stable.log','baseline.log','pip-check.log','compileall.log']:
 if (e/n).exists():copy(e/n)
with gzip.open(a/'phase2_priority4_final.xml.gz','wb') as f:f.write((e/'phase2_priority4_final.xml').read_bytes())
copy(e/'targeted-final-stable.xml')
for p in (e/'qt-cad-accepted').glob('*/*.png'):
 if not p.parent.name.endswith('current'):copy(p)
copy(e/'mixed/persian-mtext-zoom.png');copy(e/'dwg/final-real-dwg-qt.png')
for p in (e/'final-benchmark').glob('benchmark-*.json'):copy(p)
copy(e/'mixed/receipt.json','mixed-receipt.json');copy(e/'dwg/receipt.json','dwg-decode-receipt.json');copy(e/'dwg-boq-accepted/receipt.json','dwg-boq-receipt.json')
copy(e/'dwg/نقشه.dwg','synthetic-ac1032.dwg');copy(e/'dwg/reference.dxf','synthetic-reference.dxf')
with zipfile.ZipFile(a/'diagnostic-logs-and-probes.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(e.iterdir()):
  if p.is_file() and p.suffix in ('.log','.exit','.py','.xml'):z.write(p,p.name)
bench=[json.loads(p.read_text()) for p in sorted((e/'final-benchmark').glob('benchmark-*.json'))];bench.sort(key=lambda x:x['entity_count'])
commits=subprocess.check_output(['git','log','--reverse','--format=%H %s','8e3d1b7..HEAD'],text=True).splitlines()
files=subprocess.check_output(['git','diff','--name-only','8e3d1b7..HEAD'],text=True).splitlines()
mapping=['64b142a87aa4761debdba460ab8c2b3b1fa1d679','1ea6acbb327ecb04abfa32f86bc43c9a7c4b4b8b','be20c6d05d4a4e85d7da9d49b73eda1e76c8cf9e','96ec84c3840358e2364865525d2aa15227c591da','fe4ca7fa846c1c55e4a2c887570db042456b05d4','d5224d47f0f1645fb4b1328c9bb786f1d5c86b11','d466382ed51488212157eab3bb0bcd953590fb40','04b02f44e44ee2c988c5e6641a442f05da7f0e60']
limits=['بارگذاری و رندر اولیه همگام و مسدودکننده رابط است؛ پذیرش پاسخ‌گویی هنگام ورود فایل حجیم کامل نیست.', 'MINSERT، XREF حل‌نشده، HATCH، DIMENSION، SPLINE، Proxy و اندازه‌گیری مالی منحنی‌ها کامل نیستند؛ مسیر پشتیبانی‌نشده رد یا با هشدار مشخص می‌شود.', 'واحد نامعلوم یا INSUNITS=0 برای BOQ مسدود است؛ فرم تعیین واحد با مدرک مستقل افزوده نشده است.', 'فرزندان Block با Transform و مسیر Handle پشتیبانی می‌شوند؛ انتخاب/پرداخت تجمعی خود Block کامل نیست.', 'فونت جایگزین با هشدار؛ تطابق کامل SHX اصلی، alignment پیچیده و Windows تأیید نشده‌اند.', 'تنها DWG مصنوعی واقعی AC1032 با ACadSharp 3.8.0.0 آزموده شد؛ همه نسخه‌ها، فایل رمزدار، مشتری و نقشه مصوب پذیرفته نشده‌اند.', 'کنترل پیش از تعمیر Handle روی DXF متنی است؛ پشتیبانی جامع Binary DXF احراز نشده است.']
report={'date':'2026-10-21','status':'PARTIAL','initial_head':'8e3d1b701efafa32b235113de7aceeab49e9238c','protected_pr18':'3434f63ee3718f6399bbf06bc8ca7a2c6a835b29','tested_local_commit':'1fcc673f0dd16a91dc0ed347a50dde722bad92f8','tested_remote_code_commit':mapping[-1],'tested_tree':'8eddf0bffda4f9e65467a1e6e732ae78994559bc','final_head_note':'The evidence-only descendant commit containing this report is the delivery HEAD; executable/test subtrees must equal tested_tree. No circular self-SHA is embedded.','code_commits':[{'local':s.split()[0],'remote':r,'message':' '.join(s.split()[1:])} for s,r in zip(commits,mapping)],'changed_code_files':files,'tests':{'full':{'passed':7469,'failed':0,'errors':0,'skipped':5,'exit_code':0,'seconds':333.99,'skip_reason':'PowerShell runtime unavailable: tests/test_windows_build_native_failures.py:12'},'targeted_final':{'passed':97,'failed':0,'errors':0,'skipped':0,'exit_code':0},'baseline':{'passed':67,'exit_code':0},'overlap_warning':'Counts overlap; do not add. Full includes 47 new CAD cases.','command':'QT_QPA_PLATFORM=offscreen python -m pytest -q -ra --junitxml=/tmp/p4-evidence/phase2_priority4_final.xml','other_checks':['python -m compileall -q core app tests: exit 0','python -m pip check: exit 0','git diff --check: exit 0'],'failed_runs':'Retained in diagnostic ZIP; intermediate comprehensive runs had 3 failures then 1 MTEXT failure; interrupted runs exit 130 are not acceptance.'},'benchmarks':bench,'dwg':json.loads((e/'dwg/receipt.json').read_text()),'dwg_sqlite_boq':json.loads((e/'dwg-boq-accepted/receipt.json').read_text()),'limits':limits,'backup':'Separate final ZIP and independent round-trip receipt; pending at report commit, no unsupported upload-success claim.','assets':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in a.iterdir() if p.is_file()}}
(root/'docs/acceptance/phase2_priority4_cad_20261021.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
text='''# فاز ۲، اولویت ۴ — تحویل اجرایی CAD، ۲۰۲۶-۱۰-۲۱

**نتیجه کلی: PARTIAL.** DXF، تبدیل واقعی یک DWG پشتیبانی‌شده و اتصال Entity مستند به SQLite/BOQ آزموده شدند. دامنه کامل حرفه‌ای به علت محدودیت‌های زیر بسته نمی‌شود. وارد اولویت ۵ نشده‌ایم.

## مبنا و هویت نسخه

HEAD آغاز: `8e3d1b701efafa32b235113de7aceeab49e9238c`؛ PR18 محفوظ: `3434f63ee3718f6399bbf06bc8ca7a2c6a835b29`.
کد آزموده محلی: `1fcc673f0dd16a91dc0ed347a50dde722bad92f8`؛ همان درخت در Commit GitHub `04b02f44e44ee2c988c5e6641a442f05da7f0e60`:
`8eddf0bffda4f9e65467a1e6e732ae78994559bc`.
Commit تحویل حاوی این سند فقط شواهد است؛ SHA آن از Git دریافت می‌شود و زیر‌درخت‌های اجرایی/آزمون با نسخه بالا برابرند. تفاوت SHA محلی و GitHub به metadata Commit مربوط است، نه درخت کد.

## مسیر واقعی و قابلیت‌های حفظ‌شده

`app/graphical_takeoff.py → DrawingViewerModel → DWGTakeoffEngine → ezdxf / ACadSharp bridge → DrawingTakeoffSession → existing application/ProjectStore → BOQ`.
CADAdapter قدیمی و providerهای مرزی از مسیر GUI متمایزند؛ موتور یا دفتر مالی موازی ساخته نشد. PDF، سه سقف، هندسه دقیق، اصلاحیه و قفل‌های قبلی در رگرسیون جامع محفوظ‌اند. Schema، بانک خانواده، قیمت، هشت فاز و PR18 تغییر نکردند.

## تغییرات واقعی و علت

- هندسه: مساحت مربع واحد در مختصات 1e12 قبلاً 134217728 می‌شد؛ چندضلعی مستقیم اکنون از قرارداد دقیق موجود استفاده می‌کند. طول و منحنی هنوز double با tolerance آزمون‌شده‌اند، نه ادعای Decimal مطلق.
- DXF: Handle خام تکراری/هم‌ارز قبل از repair ezdxf رد می‌شود؛ مختصات نامتناهی، Z و extrusion نامعتبر، لایه/والد پنهان و واحد نامعلوم مانع مالی‌اند. Blockهای تو‌در‌تو با Transform و مسیر Handle، محدودیت عمق۳۲ و ۲۵۰هزار expanded Entity دارند. چرخه و MINSERT رد می‌شوند.
- DWG: SHA اصل با SHA DXF مبدل اشتباه نمی‌شود؛ ابزار/نسخه/Exit و SHA خروجی ثبت می‌شوند. Timeout، تغییر فایل حین تبدیل و خروجی نامعتبر رد می‌شوند. `--version` به bridge واقعی افزوده شد.
- GUI واقعی: فهرست لایه با تعداد، hide/show، جست‌وجوی Handle، انتخاب با کلیک، Highlight، متره Entity و بازبینی مستقل، ذخیره و BOQ. خطای پاک‌شدن انتخاب در mouseRelease رفع شد. tolerance چهار پیکسل فقط برای انتخاب دیداری است.
- فارسی: جای baseline، cap height، rotation و MTEXT anchor/width اصلاح شد. MTEXT فاقد width مجاز است؛ عدم وجود فونت اصلی با هشدار جایگزین همراه است. تصویر واقعی متن متصل و چندخطی بازبینی شد؛ تطابق SHX ادعا نمی‌شود.
- مالی: فقط LINE و POLYLINE مستقیم XY معتبر به طول/سطح Entity متصل‌اند. برداشت CAD بدون binding پیش‌نویس می‌ماند؛ بازبین مستقل، مدرک، طبقه/عضو/مالک، منبع و digest دوباره بررسی می‌شوند. تغییر کد، مبدأ نمایش، نشست یا نام عضو مجوز پرداخت دوم نیست. price_code از کد عملیات اختراع نمی‌شود. اصل قطعی و قفل مالی محفوظ‌اند؛ اصلاحیه CAD چندضلعی ۱۲→۱۵ از دفتر نسخه‌دار موجود آزموده شد.

## آزمون‌های اجراشده

| اجرا | PASS | FAIL | ERROR | SKIP | Exit |
|---|---:|---:|---:|---:|---:|
| Baseline CAD |67|0|0|0|0|
| هدفمند نهایی |97|0|0|0|0|
| جامع نهایی؛ 333.99 ثانیه |7469|0|0|5|0|

اعداد هم‌پوشان‌اند و جمع نمی‌شوند. ۴۷ سناریوی جدید داخل جامع‌اند. پنج Skip فقط نبود PowerShell؛ دو هشدار قدیمی JUnit/record_property. آزمون قدیمی حذف، تضعیف یا Skip اجباری نشد.

```bash
QT_QPA_PLATFORM=offscreen python -m pytest -q -ra --junitxml=/tmp/p4-evidence/phase2_priority4_final.xml
python -m compileall -q core app tests
python -m pip check
git diff --check
```

اجرای نهایی پس از آخرین تغییر کد انجام شد. فرمان دقیق هدفمند و شکست‌های قرمز/سبز و Exitهای میانی در ZIP تشخیصی‌اند. اجرای جامع میانی سه شکست سازگاری و سپس یک شکست MTEXT بدون عرض داشت؛ همه رفع و جامع نهایی تکرار شد. اجراهای متوقف‌شده Exit130 پذیرش محسوب نمی‌شوند.

## Oracle و DWG واقعی

DWG مصنوعی باینری واقعی AC1032 با DwgWriter ساخته و با DwgReader از ACadSharp 3.8.0/assembly3.8.0.0، MIT، تبدیل شد. DXF مرجع مستقل دارای خط۳-۴-۵، مستطیل۴×۳، دایره شعاع۲ و Block چرخیده است؛ شش Entity expanded قبل/بعد حفظ شدند. طول‌ها۱ و۵متر، مساحت۱۲مترمربع و دایره4π با خطای مجاز1e-12 آزموده شدند. در مختصات بزرگ، مساحت مربع۱ دقیق است؛ واحدهای m/mm/cm/in/ft با ضرایب مستقل کنترل شدند. mixed fixture طول مرجع10000m و actual10000m، اختلاف صفر، حد1e-8 دارد.

ابزار موجود با .NET SDK8.0.426 در Linux واقعاً build و اجرا شد؛ build پیش‌فرض به محدودیت Process.GetStat محیط برخورد کرد، اجرای مستقیم MSBuild موفق شد. فقط DLL managed آزمایشی، بدون Windows EXE/Release. SDK وابستگی اجباری DXF نیست. نسخه، مجوز و هش‌ها در JSON و receipt هستند. فایل جعلی تغییرپسوندداده‌شده استفاده نشد.

سناریوی واقعی نرم‌افزار با همین DWG: Entity با Handle30، خط۵متر → پیش‌نویس → رد بدون بازبینی → بازبینی مستقل مصنوعی → BOQ۵متر بدون قیمت → بستن/بازگشایی. CAS کهنه، فایل تغییرکرده و همان Entity در نشست دیگر با مبدأ متفاوت رد شدند؛ SQLite integrity=ok و BOQ هنگام رد ثابت ماند. این شاهد نرم‌افزاری مصنوعی است، نه امضای مهندس یا نقشه مصوب.

## کارایی اندازه‌گیری‌شده

| Entity | بایت فایل | ورود/رندر مسدودکننده، ثانیه | peak RSS KiB | طول مرجع/واقعی متر |
'''
for b in bench:text+=f"|{b['entity_count']}|{b['bytes']}|{b['open_parse_render_seconds']:.3f}|{b['process_peak_rss_kib']}|{b['oracle_total_length_m']} / برابر|\n"
text+='''
تمام Entityها حفظ شدند. زمان hide/show،۲۰ zoom و Handle lookup در JSON ثبت است. mixed:۲۰۰۰ Insert،۱۰۰۰ متن فارسی،۵۰لایه و۵۰۰۰ expanded؛ ۰٫۶۷۵ثانیه و۱۵۰۳۴۰KiB. این اعداد روی میزبان فعلی و هم‌زمان با بار آزمون‌اند؛ SLA یا ظرفیت نامحدود نیستند. ورود اولیه synchronous است و معیار پاسخ‌گویی حین بارگذاری کامل نشده است.

## محدودیت‌های صریح و وضعیت

'''+ '\n'.join('- '+s for s in limits)+'''

DXF/واحدها/لایه‌ها/متن/نقشه حجیم/CAD→BOQ در دامنه‌های بالا **PARTIAL**؛ DWG واقعی در AC1032 مصنوعی **COMPLETE محدود به نمونه و decoder اعلام‌شده**، پوشش عمومی DWG **PARTIAL**. رگرسیون جامع PASS. وضعیت کلی اولویت۴ PARTIAL باقی می‌ماند؛ موفقیت DXF جای DWG یا Windows نیست.

## شواهد و بازیابی

پوشه assets هم‌نام شامل لاگ جامع، JUnit فشرده، هدفمند، رسید DWG و SQLite، Benchmarks، CAD مصنوعی و تصاویر واقعی Qt است. JSON همراه SHA-256 تک‌تک فایل‌ها و هویت Commitها را دارد. ZIP تشخیصی شکست‌ها و probeهای مستقل را حفظ می‌کند. بکاپ نهایی Git bundle و داده‌ها در Dropbox و رسید مستقل بازدریافت/بازیابی جداگانه ثبت می‌شود؛ این سند پیشاپیش موفقیت آن را ادعا نمی‌کند.

![متن فارسی واقعی Qt](phase2_priority4_cad_20261021_assets/persian-mtext-zoom.png)
![Entity واقعی تا بازبینی و BOQ](phase2_priority4_cad_20261021_assets/cad-entity-review-boq.png)

## Commitها و فایل‌ها

'''
for s,r in zip(commits,mapping):text+=f"- [{r[:8]}](https://github.com/Asanda021/StructuralPro-Recovery/commit/{r}) — {' '.join(s.split()[1:])}\n"
text+='\n'+'\n'.join('- `'+f+'`' for f in files)+'\n\nPR20 باید Open/Draft، PR18 و main بدون تغییر بمانند. بدون Merge/Force Push/Actions دستی/Release/EXE؛ Windows/Office و نقشه واقعی تأیید نشده‌اند. در همین اولویت متوقف می‌شویم.\n'
(root/'docs/acceptance/phase2_priority4_cad_20261021.md').write_text(text)
print(json.dumps({'assets':len(report['assets']),'report_bytes':len(text.encode()),'code_tree':report['tested_tree']}))
