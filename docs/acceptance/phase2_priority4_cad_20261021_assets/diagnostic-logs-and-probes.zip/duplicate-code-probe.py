import sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import ezdxf
from core.platform.application import StructuralProApp
from core.drawings.takeoff_session import DrawingTakeoffSession
from core.drawings.dwg_takeoff import DWGTakeoffEngine
r=Path(tempfile.mkdtemp());d=ezdxf.new();d.units=6;e=d.modelspace().add_line((0,0),(3,4));p=r/'x.dxf';d.saveas(p);doc=DWGTakeoffEngine().import_file(p);app=StructuralProApp(r/'db');app.create_project('synthetic','P');app.add_project_floor('P','floor',level='L1');app.add_project_member('P','M1','L1','member')
for index in (1,2):
 s=DrawingTakeoffSession(str(p));i=s.add_cad_entity(doc,e.dxf.handle,'length',takeoff_code='code'+str(index),floor_id='L1',member_id='M1',quantity_owner='owner',created_by='author',reference='synthetic',scene_origin=(index*100,100));s.review_cad_entity(i.id,reviewer='other',note='5 m');record=app.save_drawing_takeoff_session('P',s)
 try:app.commit_drawing_takeoff_to_boq('P',record['session_id'],[i.id],expected_session_revision=1)
 except ValueError:print('REJECTED',index)
 else:print('ACCEPTED',index)
app.store.close()
