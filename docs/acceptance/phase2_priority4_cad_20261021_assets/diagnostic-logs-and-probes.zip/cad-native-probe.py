import os,sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/61dce18379e6/p3-final')
os.environ['STRUCTURALPRO_DWG_BRIDGE']='/tmp/p4-bridge/bridge'
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt,QPoint
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
q=QApplication([]);root=Path('/tmp/p4-evidence/dwg');w=GraphicalTakeoffDialog(pdf_path=str(root/'نقشه.dwg'));w.resize(1400,1000);w.show();q.processEvents()
original=[e.data.copy() for e in w.cad_document.entities];line=next(e for e in w.cad_document.entities if e.entity_type=='LINE' and e.data['length']==5)
w.cad_handle.setText(line.handle);QTest.mouseClick(w.cad_find,Qt.LeftButton);item=w._cad_handle_items[line.handle];assert item.isSelected()
QTest.mouseClick(w.cad_select,Qt.LeftButton);w.canvas.scene.clearSelection();QTest.mouseClick(w.canvas.viewport(),Qt.LeftButton,pos=w.canvas.mapFromScene(item.line().pointAt(.9)));q.processEvents();
if not item.isSelected():
 pos=w.canvas.mapFromScene(item.line().pointAt(.9));scene=item.line().pointAt(.9);hits=w.canvas.scene.items(scene);print('DEBUG',pos,w.canvas.viewport().rect(),[(v.data(0),v.boundingRect(),v.sceneBoundingRect()) for v in hits],[(v.data(0)) for v in w.canvas.scene.selectedItems()],w.canvas.mode,flush=True);w.grab().save(str(root/'selection-debug.png'))
assert item.isSelected(),'actual CAD mouse selection'
QTest.mouseClick(w.pan,Qt.LeftButton);w.canvas.scale_view(4);v=w.canvas.viewport();p=v.rect().center();QTest.mousePress(v,Qt.LeftButton,pos=p);QTest.mouseMove(v,p+QPoint(50,0),30);QTest.mouseRelease(v,Qt.LeftButton,pos=p+QPoint(50,0));QTest.mouseClick(w.fit,Qt.LeftButton);q.processEvents();assert original==[e.data for e in w.cad_document.entities]
w.grab().save(str(root/'final-real-dwg-qt.png'));r={'real_dwg_ui':True,'native_mouse_entity_selection':True,'native_handle_find':True,'pan_fit_preserve_geometry':True,'source_sha256':w.cad_document.source_sha256,'conversion':w.cad_document.conversion,'unit':w.cad_document.units,'expanded_entities':len(w.cad_document.entities),'status':'PASS','exit_code':0,'financial_entity_binding':'tested separately in actual DWG SQLite probe and native QTest'};(root/'ui-receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));w.close();print(r)
