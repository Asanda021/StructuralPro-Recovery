from pathlib import Path
import ezdxf
from core.drawings.dwg_takeoff import DWGTakeoffEngine
p=Path('/tmp/p4-evidence/alias.dxf');d=ezdxf.new();a=d.modelspace().add_line((0,0),(1,0));b=d.modelspace().add_line((0,1),(1,1));d.saveas(p);text=p.read_text();p.write_text(text.replace('  5\n'+b.dxf.handle+'\n','  5\n'+a.dxf.handle.lower()+'\n',1))
try:DWGTakeoffEngine().import_file(p)
except RuntimeError:print('already rejected')
else:print('ALIAS ACCEPTED')
