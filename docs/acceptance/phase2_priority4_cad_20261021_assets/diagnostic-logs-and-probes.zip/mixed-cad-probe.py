import sys,time,json,resource,math
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import ezdxf
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
root=Path('/tmp/p4-evidence/mixed');root.mkdir(exist_ok=True);p=root/'blocks-text-persian.dxf';d=ezdxf.new('R2018');d.units=6
for i in range(50):d.layers.new('لایه-'+str(i))
b=d.blocks.new('BLOCK');b.add_line((0,0),(3,4));m=d.modelspace()
for i in range(2000):m.add_blockref('BLOCK',((i%50)*10,(i//50)*10),dxfattribs={'layer':'لایه-'+str(i%50),'rotation':(i%4)*90})
for i in range(1000):m.add_mtext('ستون C'+str(i)+' — ۱۲\\Pطبقه اول',dxfattribs={'insert':((i%50)*10+1,(i//50)*10+1),'char_height':.4,'width':3,'layer':'لایه-'+str(i%50)})
d.saveas(p);q=QApplication([]);t=time.perf_counter();w=GraphicalTakeoffDialog(pdf_path=str(p));w.resize(1500,1100);w.show();q.processEvents();seconds=time.perf_counter()-t
entities=w.cad_document.entities;assert len(entities)==5000 and len([e for e in entities if e.entity_type=='LINE'])==2000;total=math.fsum(e.data['length'] for e in entities if e.entity_type=='LINE');assert abs(total-10000)<1e-8
first=next(e for e in entities if e.entity_type=='MTEXT');w.cad_handle.setText(first.handle);QTest.mouseClick(w.cad_find,Qt.LeftButton);item=w._cad_handle_items[first.handle];w.canvas.fitInView(item.sceneBoundingRect().adjusted(-1,-1,1,1),Qt.KeepAspectRatio);q.processEvents();w.grab().save(str(root/'persian-mtext-zoom.png'));w.close()
r={'synthetic':True,'modelspace_entities':3000,'expanded_entities':5000,'inserts':2000,'texts':1000,'layers':50,'open_render_seconds':seconds,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'length_oracle_m':10000,'length_actual_m':total,'absolute_error':abs(total-10000),'allowed_absolute_error_m':1e-8,'all_expanded_entities_retained':True};(root/'receipt.json').write_text(json.dumps(r,indent=2));print(r)
