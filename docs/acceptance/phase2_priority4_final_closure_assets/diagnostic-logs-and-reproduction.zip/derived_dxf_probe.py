import os,sys,json
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,str(Path.cwd()))
from core.platform.application import StructuralProApp
from core.drawings.takeoff_session import DrawingTakeoffSession
from core.drawings.dwg_takeoff import DWGTakeoffEngine
root=Path(sys.argv[1]);app=StructuralProApp(root/'db');p=app.open_project('P');old=p['takeoffs'][0]['params']['cad_evidence'];dxf=Path('/tmp/p4-close/converted-artifacts')/(old['conversion']['output_sha256']+'.dxf');assert dxf.is_file()
app.add_project_member('P','M2','L1','same converted source alternative label');doc=DWGTakeoffEngine.with_array_support().import_file(dxf);parent=next(e for e in doc.entities if e.entity_type=='INSERT');s=DrawingTakeoffSession(str(dxf));i=s.add_cad_entity(doc,parent.handle,'length',takeoff_code='other-code',floor_id='L1',member_id='M2',quantity_owner='alternative label',created_by='author',reference='same DWG converted bytes');s.review_cad_entity(i.id,reviewer='other',note='explicit 30 m');r=app.save_drawing_takeoff_session('P',s);before=deepcopy(app.open_project('P'))
try:app.commit_drawing_takeoff_to_boq('P',r['session_id'],[i.id],expected_session_revision=1)
except ValueError:assert app.open_project('P')==before;result='REJECTED'
else:result='UNSAFE_SECOND_PAYMENT'
app.store.close();print(result);assert result=='REJECTED'
