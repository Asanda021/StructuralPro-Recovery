"""Synthetic binary AC1032: real decoder, array ownership and existing amendment journal."""
import os,sys,json,subprocess,hashlib,shutil
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,os.environ.get('STRUCTURALPRO_SOURCE_ROOT',str(Path.cwd())))
import ezdxf
from core.drawings.dwg_takeoff import DWGTakeoffEngine
from core.drawings.takeoff_session import DrawingTakeoffSession
from core.platform.application import StructuralProApp
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
writer=os.environ['CAD_FIXTURE_WRITER'];host=os.environ['DOTNET_HOST']
def drawing(name,columns):
 d=ezdxf.new('R2018');d.units=6;d.header['$DIMSTYLE']='Standard';b=d.blocks.new('B');b.add_line((0,0),(3,4));b.add_mtext('ستون C1 — ۱۲\\Pطبقه اول',dxfattribs={'insert':(1,1),'char_height':.5,'width':4});d.modelspace().add_blockref('B',(10,20),dxfattribs={'row_count':2,'column_count':columns,'row_spacing':7,'column_spacing':9,'rotation':90})
 dxf=root/(name+'.dxf');dwg=root/(name+'.dwg');d.saveas(dxf);subprocess.run([host,writer,str(dxf),str(dwg)],check=True)
 assert dwg.read_bytes().startswith(b'AC1032');doc=DWGTakeoffEngine.with_array_support().import_file(dwg);assert doc.conversion['decoder_version']=='3.8.0.0'
 lines=[e for e in doc.entities if e.entity_type=='LINE'];assert len(lines)==2*columns and sum(e.data['length'] for e in lines)==2*columns*5
 parent=next(e for e in doc.entities if e.entity_type=='INSERT')
 s=DrawingTakeoffSession(str(dwg));i=s.add_cad_entity(doc,parent.handle,'length',takeoff_code='explicit-line-operation',floor_id='L1',member_id='M1',quantity_owner='explicit synthetic sole owner',created_by='author',reference='2 rows × columns × 5 m line oracle, source array spacing explicit')
 s.review_cad_entity(i.id,reviewer='independent reviewer',note='3-4-5 analytic oracle and explicit array count');return s,i,doc
app=StructuralProApp(root/'db');app.create_project('مصنوعی؛ نقشه مصوب نیست','P');app.add_project_floor('P','طبقه',level='L1');app.add_project_member('P','M1','L1','عضو')
s,i,doc=drawing('original',3);r=app.save_drawing_takeoff_session('P',s);app.commit_drawing_takeoff_to_boq('P',r['session_id'],[i.id],expected_session_revision=1);original=deepcopy(app.open_project('P'));assert original['boq'][0]['quantity']==30 and original['boq'][0].get('price_code') is None
newer,j,doc2=drawing('revised',4);key=original['takeoffs'][0]['source_id'];amendment_doc=app.drawing_amendment_document('P',key,newer.to_dict(),expected_revision=1,expected_session_revision=2);f=root/'amendment-proof.json';f.write_text(json.dumps(amendment_doc,ensure_ascii=False));a=app.create_drawing_amendment('P',key,newer.to_dict(),expected_revision=1,expected_session_revision=2,created_by='author',reason='explicit array 3 to 4 columns',evidence={'evidence_path':str(f),'evidence_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'evidence_reference':'synthetic, independently reviewed dimension schedule'})
app.review_beam_amendment('P',a['id'],expected_revision=1,reviewer='independent reviewer',note='40 m, delta +10 m');app.apply_beam_amendment('P',a['id'],expected_revision=1);final=deepcopy(app.open_project('P'));assert final['boq'][0]['quantity']==40 and final['takeoffs']==original['takeoffs']
def rejected(label,fn):
 before=deepcopy(app.open_project('P'))
 try:fn()
 except (ValueError,RuntimeError):pass
 else:raise AssertionError(label)
 assert app.open_project('P')==before
rejected('duplicate amendment',lambda:app.apply_beam_amendment('P',a['id'],expected_revision=1));rejected('stale CAS',lambda:app.save_drawing_takeoff_session('P',newer,session_id=r['session_id'],expected_revision=0))
app.store.close();app=StructuralProApp(root/'db');assert app.open_project('P')==final;assert app.store.db.execute('pragma integrity_check').fetchone()[0]=='ok';app.store.close()
(root/'project.json').write_text(json.dumps(final,ensure_ascii=False,indent=2));(root/'session.json').write_text(json.dumps(s.to_dict(),ensure_ascii=False,indent=2));(root/'revised-session.json').write_text(json.dumps(newer.to_dict(),ensure_ascii=False,indent=2))
receipt={'synthetic':True,'binary_dwg_header':'AC1032','decoder':doc.conversion,'source_sha256':doc.source_sha256,'original_array_lines':6,'original_oracle_m':30,'revised_array_lines':8,'revised_oracle_m':40,'effective_boq_m':40,'delta_m':10,'original_takeoffs_unchanged':True,'reopen_equal':True,'integrity':'ok','duplicate_amendment_rejected':True,'stale_CAS_rejected':True,'exit_code':0};(root/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
