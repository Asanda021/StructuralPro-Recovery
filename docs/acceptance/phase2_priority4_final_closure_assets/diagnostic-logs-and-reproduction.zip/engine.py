from pathlib import Path
p=Path('core/drawings/dwg_takeoff.py');s=p.read_text().replace('budget=None,parent_visible=True):','budget=None,parent_visible=True,allow_arrays=False):')
s=s.replace("if e.mcount>1:raise ValueError('آرایه MINSERT خارج از قرارداد فعلی است؛ حذف خاموش نمونه‌ها مجاز نیست')",'''if str(e.dxf.name) in names or len(names)>=32:raise ValueError('چرخه یا عمق نامعتبر بلوک CAD')
            if e.mcount>1:
                if not allow_arrays:raise ValueError('آرایه MINSERT نیازمند قرارداد توسعه صریح است')
                rows=e.dxf.row_count;cols=e.dxf.column_count
                if rows*cols>250000 or any(not math.isfinite(float(e.dxf.get(k,0))) or float(e.dxf.get(k,0))<=0 for k,c in [('row_spacing',rows),('column_spacing',cols)] if c>1):raise ValueError('تعداد یا فاصله آرایه MINSERT نامعتبر است')
                instances=list(e.multi_insert())
                if len(instances)!=rows*cols:raise ValueError('نمونه‌های منطبق آرایه مجاز نیستند')
                for i,instance in enumerate(instances):
                    cell=identity[:-1]+(handle+'@'+str(i//cols)+','+str(i%cols),)
                    skipped=[];virtual=list(instance.virtual_entities(skipped_entity_callback=lambda entity,reason:skipped.append(str(reason))))
                    if skipped:raise ValueError('تبدیل کامل آرایه ممکن نیست')
                    yield from _expanded_entities(virtual,document,warnings,cell,names+(str(e.dxf.name),),layer,budget,visible,allow_arrays)
                continue''')
s=s.replace('layer,budget,visible)\n','layer,budget,visible,allow_arrays)\n')
s=s.replace('class DWGTakeoffEngine:\n','''class DWGTakeoffEngine:
    def __init__(self, *, allow_arrays=False):self.allow_arrays=allow_arrays

    @classmethod
    def with_array_support(cls):return cls(allow_arrays=True)

''')
s=s.replace("        if not source_bytes.startswith(b'AutoCAD Binary DXF'):","        if source_bytes.startswith(b'AutoCAD Binary DXF'):raise RuntimeError('Binary DXF خارج از قرارداد تأییدشده است؛ تبدیل معتبر به DXF متنی لازم است')\n        if not source_bytes.startswith(b'AutoCAD Binary DXF'):")
s=s.replace('_expanded_entities(entities,doc,out.warnings):','_expanded_entities(entities,doc,out.warnings,allow_arrays=self.allow_arrays):')
p.write_text(s)
for name in ['core/drawings/viewer_model.py','core/drawings/takeoff_session.py']:
 p=Path(name);s=p.read_text().replace('DWGTakeoffEngine().import_file(', 'DWGTakeoffEngine.with_array_support().import_file(');p.write_text(s)
