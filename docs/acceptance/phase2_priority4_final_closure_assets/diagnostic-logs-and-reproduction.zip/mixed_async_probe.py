import sys,time,json,resource,gc
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import ezdxf
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True);d=ezdxf.new('R2018');d.units=6
for i in range(20):d.layers.new('سازه-'+str(i))
b=d.blocks.new('B');b.add_line((0,0),(3,4));b.add_mtext('ستون C1 — ۱۲\\Pطبقه اول',dxfattribs={'insert':(1,1),'char_height':.5,'width':4})
for i in range(1500):d.modelspace().add_blockref('B',(i*30,0),dxfattribs={'row_count':2,'column_count':3,'row_spacing':7,'column_spacing':9,'rotation':90,'layer':'سازه-'+str(i%20)})
for i in range(1000):d.modelspace().add_mtext('طبقه ۱۲ — B1',dxfattribs={'insert':(i*30,30),'char_height':.5})
p=root/'arrays-persian.dxf';d.saveas(p);del d,b;gc.collect();q=QApplication([]);w=GraphicalTakeoffDialog();w.show();ticks=[];timer=QTimer();timer.timeout.connect(lambda:ticks.append(time.monotonic()));timer.start(10);start=time.monotonic();ticks.append(start);w.open_cad_async(str(p));end=start+60
while w.cad_loading and time.monotonic()<end:QTest.qWait(10)
assert not w.cad_loading;elapsed=time.monotonic()-start;QTest.qWait(30);assert len(w.cad_document.entities)==20500;assert sum(e.data.get('length',0) for e in w.cad_document.entities)==45000;assert len(w.cad_document.text_labels)==10000;gap=max(b-a for a,b in zip(ticks,ticks[1:]));assert gap<.5
w.grab().save(str(root/'mixed-qt.png'));timer.stop();w.close();r={'synthetic':True,'arrays':1500,'cells_per_array':6,'expanded_entities':20500,'text_entities':10000,'oracle_m':45000,'actual_m':45000,'elapsed_s':elapsed,'max_event_gap_s':gap,'event_timestamps':ticks,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'exit_code':0};(root/'receipt.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k!='event_timestamps'})
