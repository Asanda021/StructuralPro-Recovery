import os,sys,time,json,gc
from pathlib import Path
sys.path.insert(0,os.environ.get('STRUCTURALPRO_SOURCE_ROOT',str(Path.cwd())))
import ezdxf
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QProcess,QTimer
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
from core.platform.application import StructuralProApp
from copy import deepcopy
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True);d=ezdxf.new('R2018');d.units=6
for i in range(2000):d.modelspace().add_line((i,0),(i+3,4))
p=root/'valid.dxf';d.saveas(p);bad=root/'bad-mid-parse.dxf';d.modelspace().add_line((0,0),(float('nan'),0));d.saveas(bad)
q=QApplication([]);app=StructuralProApp(root/'db');app.create_project('synthetic','P');before=deepcopy(app.open_project('P'));samples=[]
def wait(fn):
 end=time.monotonic()+20
 while not fn() and time.monotonic()<end:QTest.qWait(10)
 assert fn()
for i in range(5):
 w=GraphicalTakeoffDialog(app_service=app,project_id='P');w.show();w.open_cad_async(str(p));wait(lambda:not w.cad_loading);assert len(w.cad_document.entities)==2000
 w.open_cad_async(str(bad));wait(lambda:not w.cad_loading);assert w.viewer.path==p and len(w.cad_document.entities)==2000 and 'خطا' in w.status.text()
 w.open_cad_async(str(p));QTest.qWait(20);w.cancel_cad_loading();QTest.qWait(30);assert not w.findChildren(QProcess)
 w.close();w.deleteLater();QTest.qWait(30);del w;gc.collect();samples.append(int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE'))
assert app.open_project('P')==before;app.store.close();result={'synthetic':True,'cycles':5,'entities_per_load':2000,'mid_parse_error_preserves_previous':True,'no_stranded_QProcess':True,'sqlite_and_boq_unchanged':True,'rss_after_each_close_bytes':samples,'memory_note':'Observed current RSS, including Qt/allocator cache; five cycles do not prove absence of every long-run leak.','exit_code':0};(root/'receipt.json').write_text(json.dumps(result,indent=2));print(result)
