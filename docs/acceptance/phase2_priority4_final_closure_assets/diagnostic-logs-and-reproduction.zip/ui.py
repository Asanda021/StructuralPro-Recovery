from pathlib import Path
p=Path('app/graphical_takeoff.py');s=p.read_text()
s=s.replace('        self.cad_cancel=QPushButton',"        self.cad_unit_button=QPushButton('واحد مستند CAD');self.cad_unit_button.clicked.connect(self.open_cad_unit_dialog)\n        self.cad_cancel=QPushButton",1)
s=s.replace('self.cad_measure,self.cad_review,self.cad_cancel):','self.cad_measure,self.cad_review,self.cad_cancel,self.cad_unit_button):',1)
s=s.replace("        if len(selected)!=1:\n            self.status", "        root_handle=getattr(self,'_selected_cad_root',None)\n        if root_handle:\n            expected={h for h in self._cad_handle_items if h.startswith(root_handle+'/') or h.startswith(root_handle+'@')}\n            if {str(i.data(0)) for i in selected}!=expected:root_handle=None\n        if len(selected)!=1 and not root_handle:\n            self.status",1)
s=s.replace("self.session.add_cad_entity(self.cad_document,str(selected[0].data(0))", "self.session.add_cad_entity(self.cad_document,root_handle or str(selected[0].data(0))",1)
s=s.replace("        if item is None:self.status.setText('جزء قابل نمایش با این شناسه یافت نشد');return", """        self._selected_cad_root=None
        if item is None:
            children=[item for handle,item in self._cad_handle_items.items() if handle.startswith(key+'/') or handle.startswith(key+'@')]
            if not children:self.status.setText('جزء قابل نمایش یافت نشد؛ XREF حل‌نشده یا نوع پشتیبانی‌نشده مجوز متره ندارد');return
            for child in children:child.setVisible(True);child.setSelected(True)
            self._selected_cad_root=key;self.canvas.centerOn(children[0]);self.status.setText('بلوک انتخاب شد: '+key+'؛ اجزا برای جمع کنترل‌شده بازبینی شوند');return""",1)
s=s.replace('        if item.kind == "length" and len(item.geometry) >= 2:',"        if (item.cad_evidence or {}).get('metric_contract')=='cad_analytic_v1':return\n        if item.kind == \"length\" and len(item.geometry) >= 2:",1)
s=s.replace('        self.canvas.highlight_measurement(item)\n        self.geometry_components',"        if item.cad_evidence:\n            self.cad_handle.setText(item.cad_evidence['handle']);self.find_cad_handle()\n        else:self.canvas.highlight_measurement(item)\n        self.geometry_components",1)
s=s.replace('elif entity.entity_type in {"TEXT","MTEXT"} and d.get("text"):', 'elif entity.entity_type in {"TEXT","MTEXT","DIMENSION"} and d.get("text"):')
s=s.replace("self.cad_metric.addItem('طول مستقیم','length');self.cad_metric.addItem('سطح بسته مستقیم','area')", "self.cad_metric.addItem('طول / محیط معتبر','length');self.cad_metric.addItem('سطح بسته معتبر','area')")
s=s.replace('فقط خط و چندضلعی مستقیم معتبر؛ منحنی و دیتایل مصالح مستقل‌اند','خط، چندضلعی مستقیم، دایره و کمان تحلیلی یا جمع اجزای بلوک؛ بدون حدس مصالح')
i=s.index('    def beam_drawing_context(self):')
new='''    def open_cad_unit_dialog(self):
        if self.cad_loading or not self.cad_document:return
        dialog=QDialog(self);dialog.setWindowTitle('واحد مستند CAD — مدرک و بازبینی مستقل');dialog.setLayoutDirection(Qt.RightToLeft)
        form=QFormLayout(dialog);form.addRow(QLabel('واحد فایل: '+self.cad_document.units+'؛ انتخاب دلخواه واحد مجوز مالی نیست'))
        path=QLineEdit();path.setObjectName('cad_unit_document');browse=QPushButton('انتخاب مدرک JSON مستقل واحد');summary=QLabel();summary.setWordWrap(True);apply=QPushButton('بررسی مدرک و تأیید صریح واحد');apply.setObjectName('cad_unit_apply')
        form.addRow('مسیر مدرک',path);form.addRow(browse);form.addRow(summary);form.addRow(apply)
        browse.clicked.connect(lambda:path.setText(QFileDialog.getOpenFileName(dialog,'مدرک مستقل واحد','','JSON (*.json)')[0]))
        def accept():
            try:
                if self.session.items:raise ValueError('متره قبلی نباید بازتفسیر شود؛ نشست یا اصلاحیه مستقل لازم است')
                import hashlib
                from core.drawings.dwg_takeoff import apply_documented_units
                p=Path(path.text());e={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};doc=apply_documented_units(self.cad_document,e);proof=json.loads(p.read_text(encoding='utf-8-sig'))
                labels={'unit':'واحد پیشنهادی','reference_handle':'شناسه هندسه مرجع','cad_length':'طول مرجع در CAD','real_length_m':'طول معلوم واقعی (متر)','author':'ثبت‌کننده','reviewer':'بازبین مستقل','reference':'نوع و مرجع مدرک','source_sha256':'SHA-256 منبع'}
                summary.setText('\\n'.join(label+': '+str(proof.get(k,'')) for k,label in labels.items())+'\\nSHA-256 مدرک: '+e['sha256'])
                if QMessageBox.question(dialog,'تأیید واحد',summary.text()+'\\nواحد مستند اعمال شود؟',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
                self.cad_document=doc;self.viewer.cad_document=doc;self.load_page(1);dialog.accept()
            except Exception as exc:summary.setText('واحد اعمال نشد: '+str(exc))
        apply.clicked.connect(accept);dialog.exec()

'''
s=s[:i]+new+s[i:];p.write_text(s)
