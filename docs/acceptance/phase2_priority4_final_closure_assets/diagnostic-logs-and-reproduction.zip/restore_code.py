from pathlib import Path
import json,zipfile,hashlib,subprocess,sqlite3
root=Path('/tmp/p4-close');z=root/'roundtrip-code.zip';expected='98b76f200167f6077827547674933263c7cb951b82f6e0a6e19bc701a00ff169';assert hashlib.sha256(z.read_bytes()).hexdigest()==expected
out=root/'restored'
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None;assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in f.namelist());f.extractall(out)
m=json.loads((out/'Manifest.json').read_text())
for name,digest in m['files'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest,name
subprocess.run(['git','clone','-b','p4-closure-code',str(out/'StructuralPro_P4_closure_code.bundle'),str(out/'repo')],check=True);subprocess.run(['git','fsck','--full'],cwd=out/'repo',check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=out/'repo',text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=out/'repo',text=True).strip();assert head==m['code_head'] and tree==m['tested_tree']
dbs=[]
for p in out.rglob('*.db'):
 con=sqlite3.connect(p);assert con.execute('pragma integrity_check').fetchone()[0]=='ok';assert con.execute('pragma foreign_key_check').fetchall()==[];con.close();dbs.append(str(p.relative_to(out)))
p=out/'real-dwg-final';con=sqlite3.connect(p/'db/projects.db');payload=json.loads(con.execute('select payload from projects where id=?',('P',)).fetchone()[0]);con.close();snapshot=json.loads((p/'project.json').read_text());snapshot.pop('_meta',None);assert payload==snapshot
r=json.loads((p/'receipt.json').read_text());assert hashlib.sha256((p/'original.dwg').read_bytes()).hexdigest()==r['source_sha256'];converted=r['decoder']['output_sha256'];assert hashlib.sha256((out/'converted-artifacts'/f'{converted}.dxf').read_bytes()).hexdigest()==converted
launcher=out/'restored-bridge';launcher.write_text('#!/bin/sh\nexec /tmp/p4-close/dotnet/dotnet "'+str(out/'converter/StructuralPro.DwgBridge.dll')+'" "$@"\n');launcher.chmod(0o755)
result={'primary_archive':'/StructuralPro/Backups/StructuralPro_P4_Closure_f0bf3eec_20261021.zip','sha256':expected,'manifest_files_verified':len(m['files']),'git_fsck_exit':0,'code_head':head,'tested_tree':tree,'sqlite_integrity_and_foreign_keys':'PASS','databases':dbs,'stored_snapshot_equal':True,'dwg_and_exact_converted_bytes_sha_verified':True,'signed_stored_paths_rewritten':False,'tests':'PENDING'};(root/'restore-receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
