"""Analytic array transform oracle, independent of product/ezdxf measurements."""
import sys,math,json,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import ezdxf
from core.drawings.dwg_takeoff import DWGTakeoffEngine,cad_entity_geometry
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True);results=[]
for index,(sx,sy,angle) in enumerate([(2,.5,30),(-1,1,90),(1,-2,45),(2,2,0)]):
 d=ezdxf.new('R2018');d.units=6;b=d.blocks.new('B');b.add_line((0,0),(3,4));e=d.modelspace().add_blockref('B',(10,20),dxfattribs={'row_count':2,'column_count':3,'row_spacing':7,'column_spacing':9,'rotation':angle,'xscale':sx,'yscale':sy});p=root/f'transform-{index}.dxf';d.saveas(p);doc=DWGTakeoffEngine.with_array_support().import_file(p);lines=[v for v in doc.entities if v.entity_type=='LINE'];expected_each=math.sqrt((3*sx)**2+(4*sy)**2);actual=cad_entity_geometry(doc,e.dxf.handle,'length')[2];expected=6*expected_each;assert math.isclose(actual,expected,rel_tol=1e-12,abs_tol=0)
 theta=angle*math.pi/180;c=math.cos(theta);s=math.sin(theta)
 for row in range(2):
  for col in range(3):
   line=next(v for v in lines if f'@{row},{col}/' in v.handle);x=col*9;y=row*7;start=(10+c*x-s*y,20+s*x+c*y);end=(start[0]+c*(3*sx)-s*(4*sy),start[1]+s*(3*sx)+c*(4*sy));assert all(math.isclose(a,b,abs_tol=1e-10,rel_tol=0) for a,b in zip(line.data['start'],start));assert all(math.isclose(a,b,abs_tol=1e-10,rel_tol=0) for a,b in zip(line.data['end'],end))
 results.append({'scale':[sx,sy],'angle_degrees':angle,'array':[2,3],'oracle_total_m':expected,'actual_total_m':actual,'absolute_error_m':abs(actual-expected),'coordinate_abs_tolerance_m':1e-10,'metric_rel_tolerance':1e-12})
(root/'receipt.json').write_text(json.dumps({'synthetic':True,'cases':results,'exit_code':0},indent=2));print(json.dumps(results))
