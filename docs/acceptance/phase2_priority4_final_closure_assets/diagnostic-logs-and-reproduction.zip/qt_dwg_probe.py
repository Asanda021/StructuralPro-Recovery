"""Real offscreen Qt, restored ACadSharp converter; synthetic DWG only."""
import os,sys,json,time
from pathlib import Path
sys.path.insert(0,os.environ.get('STRUCTURALPRO_SOURCE_ROOT',str(Path.cwd())))
from PySide6.QtWidgets import QApplication,QInputDialog,QDialogButtonBox,QMessageBox
from PySide6.QtCore import QTimer,Qt
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
from core.platform.application import StructuralProApp
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True);source=Path(sys.argv[2]);q=QApplication([]);app=StructuralProApp(root/'db');app.create_project('مصنوعی؛ طراحی مصوب نیست','P');app.add_project_floor('P','طبقه',level='L1');app.add_project_member('P','M1','L1','عضو')
w=GraphicalTakeoffDialog(app_service=app,project_id='P');w.resize(1500,1050);w.show();w.open_cad_async(str(source));end=time.monotonic()+30
while w.cad_loading and time.monotonic()<end:QTest.qWait(10)
assert not w.cad_loading and w.viewer.path==source
parent=next(e for e in w.cad_document.entities if e.entity_type=='INSERT');w.cad_handle.setText(parent.handle);QTest.mouseClick(w.cad_find,Qt.LeftButton);assert len(w.canvas.scene.selectedItems())==12
w.polygon_floor.setText('L1');w.polygon_member.setText('M1');w.polygon_owner.setText('explicit synthetic sole owner');errors=[]
def answers(values):
 queue=list(values)
 def respond():
  modal=q.activeModalWidget()
  try:
   assert isinstance(modal,QInputDialog);modal.setTextValue(queue.pop(0))
   if queue:QTimer.singleShot(20,respond)
   QTest.mouseClick(modal.findChild(QDialogButtonBox).button(QDialogButtonBox.Ok),Qt.LeftButton)
  except Exception as exc:
   errors.append(str(exc))
   if modal:modal.reject()
 QTimer.singleShot(20,respond)
answers(['explicit-line-operation','author','2 rows x 3 columns x 5 m explicit oracle']);QTest.mouseClick(w.cad_measure,Qt.LeftButton);assert not errors and len(w.session.items)==1 and w.session.items[0].quantity==30
QTest.mouseClick(w.table.viewport(),Qt.LeftButton,pos=w.table.visualItemRect(w.table.item(0,0)).center());print('SELECTION',w.table.currentRow(),w.page,flush=True);answers(['independent reviewer','30 m synthetic oracle']);QTest.mouseClick(w.cad_review,Qt.LeftButton);print('REVIEW',errors,w.status.text(),w.session.items[0].cad_evidence.get('review'),flush=True);assert not errors and w.session.items[0].cad_evidence.get('review');QTest.mouseClick(w.save_session_button,Qt.LeftButton)
QTest.mouseClick(w.table.viewport(),Qt.LeftButton,pos=w.table.visualItemRect(w.table.item(0,0)).center())
def confirm():
 m=q.activeModalWidget();assert isinstance(m,QMessageBox);QTest.mouseClick(m.button(QMessageBox.Yes),Qt.LeftButton)
print('BEFORE COMMIT',w.commit_boq_button.isEnabled(),w.table.currentRow(),[x.row() for x in w.table.selectionModel().selectedRows()],w.status.text(),flush=True)
QTimer.singleShot(20,confirm);QTest.mouseClick(w.commit_boq_button,Qt.LeftButton);print('AFTER',w.status.text(),flush=True);assert app.open_project('P')['boq'][0]['quantity']==30
for _ in range(3):QTest.mouseClick(w.zoom_in,Qt.LeftButton);QTest.mouseClick(w.zoom_out,Qt.LeftButton)
QTest.mouseClick(w.pan,Qt.LeftButton);QTest.mousePress(w.canvas.viewport(),Qt.LeftButton,pos=w.canvas.viewport().rect().center());QTest.mouseMove(w.canvas.viewport(),w.canvas.viewport().rect().center()+__import__('PySide6.QtCore',fromlist=['QPoint']).QPoint(30,20));QTest.mouseRelease(w.canvas.viewport(),Qt.LeftButton);QTest.mouseClick(w.fit,Qt.LeftButton)
w.grab().save(str(root/'real-dwg-qt.png'));receipt={'synthetic':True,'decoder':w.cad_document.conversion,'device_pixel_ratio':w.devicePixelRatioF(),'qt_scale_factor':os.environ.get('QT_SCALE_FACTOR','1'),'array_lines':6,'highlighted_graphics':12,'oracle_m':30,'boq_m':app.open_project('P')['boq'][0]['quantity'],'real_mouse_and_native_dialogs':True,'exit_code':0};(root/'receipt.json').write_text(json.dumps(receipt,indent=2));w.close();app.store.close();print(receipt)
