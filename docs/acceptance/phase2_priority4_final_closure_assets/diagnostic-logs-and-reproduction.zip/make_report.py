from pathlib import Path
import json,hashlib,subprocess,shutil,zipfile,gzip,xml.etree.ElementTree as ET
repo=Path.cwd();e=Path('/tmp/p4-close');a=repo/'docs/acceptance/phase2_priority4_final_closure_assets';a.mkdir(exist_ok=True)
def copy(p,name=None):
 p=Path(p);target=a/(name or p.name);shutil.copy2(p,target);return target.name
full=ET.parse(e/'phase2_priority4_closure_accepted.xml').getroot().find('testsuite');assert full.attrib['failures']=='0' and full.attrib['errors']=='0';assert (e/'full-accepted.exit').read_text().strip()=='0'
for n in ['full-accepted.log','lineage-targeted.log','chunked-targeted.log','final-compileall.log','final-pip-check.log','derived-red.log','derived-green.log','real-dwg-final.log','ui-final-100.log','ui-final-150.log','stress.log','transform-oracle.log']:
 if (e/n).exists():copy(e/n)
with gzip.open(a/'phase2_priority4_closure.xml.gz','wb') as f:f.write((e/'phase2_priority4_closure_accepted.xml').read_bytes())
for folder in ['ui-final-100','ui-final-150','real-dwg-final','transform-oracle','stress','mixed-final']:
 p=e/folder/'receipt.json'
 if p.exists():copy(p,folder+'-receipt.json')
for folder in ['ui-final-100','ui-final-150']:
 p=e/folder/'real-dwg-qt.png'
 if p.exists():copy(p,folder+'.png')
for p in (e/'accepted-performance').glob('*/responsiveness.json'):
 if p.parent.name.endswith('current'):continue
 count=json.loads(p.read_text())['entities'];copy(p,f'benchmark-{count}.json')
for p in (e/'final-acceptance').glob('*/documented-unit-qt.png'):
 if not p.parent.name.endswith('current'):copy(p,'documented-unit-qt.png')
for p in (e/'final-acceptance').glob('*/persian-block-qt.png'):
 if not p.parent.name.endswith('current'):copy(p,'persian-block-qt.png')
if (e/'mixed-final/mixed-qt.png').exists():copy(e/'mixed-final/mixed-qt.png')
with zipfile.ZipFile(a/'diagnostic-logs-and-reproduction.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in e.iterdir():
  if p.is_file() and p.suffix in {'.py','.log','.exit','.xml'}:z.write(p,p.name)
receipt=json.loads((e/'restore-receipt.json').read_text()) if (e/'restore-receipt.json').exists() else None
if receipt:
 assert receipt.get('tests')=='PASS'
 copy(e/'restore-receipt.json')
bench=[json.loads(p.read_text()) for p in sorted(a.glob('benchmark-*.json'))];bench.sort(key=lambda d:d['entities'])
code='f0bf3eec998d391ddaf62c81f827f73c9d7913dc';tree='7912f377e3d7129f5b247f49a492161b6e91c0f5'
commits=[('0f63c8e3d327998b297c7178070d647b80872fb0','Worker، مدرک واحد و قرارداد صریح آرایه'),('f2169c904491ea6275a771b37e3922c4bc83478e','دایره/کمان، جمع بلوک، فرم واحد و دفتر اصلاحیه موجود'),('5832d87cf386bc7041a63a1224e8c21af826d97c','حفاظت صحنه مرحله‌ای در برابر تغییر صفحه/نشست'),('f56ae61c73293d075360200e71ffb26f3c9db388','دریافت مدل در بسته‌های ۱۰۰۰جزئی و رندر ۱۲۸جزئی'),(code,'تطبیق منشأ DWG/DXF با سوابق مالی تاریخی و علت XREF')]
files=subprocess.check_output(['git','diff','--name-only','7ebe8505..HEAD','--','app','core','tests'],text=True).splitlines()
entities={'LINE':'طول XY از نقاط واقعی؛ قابل ثبت پس از مدرک و بازبینی','LWPOLYLINE/POLYLINE':'مسیر مستقیم طول و سطح بسته؛ سطح از planar_geometry دقیق موجود، حلقه ساده حداکثر۱۲۸ رأس','CIRCLE':'طول محیط و سطح تحلیلی از شعاع منبع؛ double متناهی با قرارداد تطبیق نسبی1e-12، بدون تقریب پاره‌خطی مالی','ARC':'طول تحلیلی قوس؛ کمان باز سطح قابل پرداخت ندارد','INSERT/MINSERT':'اجزای مستقیم/تحلیلی مجاز، تبدیل واقعی ezdxf، هویت @row,column، عمق۳۲ و سقف۲۵۰هزار expanded؛ جمع غیرهم‌پوشان با مالکیت صریح','TEXT/MTEXT':'نمایش فارسی و دوران/anchor؛ هیچ مقدار مالی مستقیم ندارد','DIMENSION':'نمایش متن annotation خود سند؛ placeholder ممکن است باقی بماند؛ فلش/چیدمان کامل و استخراج مالی خارج از قرارداد','HATCH':'تشخیص/هشدار و منع متره قطعی؛ سطح ظاهری جای حلقه معتبر نیست','SPLINE/ELLIPSE/Proxy':'تشخیص و منع متره مستقیم؛ نمایش کامل/طول مالی خارج از قرارداد','XREF حل‌نشده':'علت فارسی صریح؛ داخل بلوک هم تجمیع مالی را مسدود می‌کند','bulge':'پیش‌نمایش تحلیلی قبلی محفوظ؛ ثبت مالی مستقیم منحنی bulge در این قرارداد مسدود است','Binary DXF':'تشخیص امضا و رد فارسی پیش از ezdxf؛ نیاز به تبدیل معتبر به DXF متنی'}
gates={k:{'status':'COMPLETE' if k!='G' or receipt else 'PENDING_BACKUP','evidence':v} for k,v in {'A':'Qt event loop timestamps; 10k/50k/100k; cancel/replace/error/close/staged-page; five lifecycle cycles','B':'native RTL document dialog; source and evidence SHA; actual unit reference; independent author/reviewer; SQLite/CAS/undo/redo/empty draft','C':'array rotation/mirror/nonuniform scale oracle; real DWG MINSERT; native child highlight; parent-child batch/history rejection','D':'source-coordinate oracles and explicit negative entity/format matrix','E':'TEXT/MTEXT RTL, real rotated Block, native screenshots, DPI 1 and 1.5, disclosed system font fallback','F':'real binary AC1032 30m to BOQ then existing immutable amendment 40m; SQLite/reopen/CAS; converted-DXF duplicate red/green','G':'full accepted JUnit/tree and separate Dropbox restore receipt'}.items()}
result={'date':'2026-10-21','initial_head':'7ebe8505ecffcc1b81995670ba2e576a3ce090e6','protected_pr18_head':'3434f63ee3718f6399bbf06bc8ca7a2c6a835b29','tested_local_commit':'1524399cd6414729bd2bdd3721ff2b7b45b2dd26','tested_code_commit':code,'tested_tree':tree,'delivery_head_note':'The evidence-only descendant containing this file is the delivery HEAD; its app/core/tests component trees equal the tested code. Avoids a circular self-SHA.','gates':gates,'overall_status':'COMPLETE' if receipt else 'PENDING_BACKUP','commits':dict(commits),'changed_files':files,'full':{'passed':int(full.attrib['tests'])-int(full.attrib['skipped']),'failures':0,'errors':0,'skipped':int(full.attrib['skipped']),'exit_code':0,'duration_s':full.attrib['time'],'skip_reason':'PowerShell runtime unavailable, tests/test_windows_build_native_failures.py:12'},'targeted':{'chunked_full_pdf_cad_subset':{'passed':144,'exit_code':0},'final_lineage_subset':{'passed':142,'deselected':3,'exit_code':0},'note':'Overlapping runs, not additive; all final tests are covered by final comprehensive JUnit.'},'benchmarks':bench,'entity_matrix':entities,'dwg':json.loads((e/'real-dwg-final/receipt.json').read_text()),'array_transform_oracle':json.loads((e/'transform-oracle/receipt.json').read_text()),'backup_restore':receipt,'limits':['Only synthetic binary AC1032 tested with actual ACadSharp3.8.0.0 MIT; other DWG versions not claimed.','Windows/Office, customer approved plans, unavailable original SHX fonts, unresolved XREF/proxies are explicitly outside this fixed nonWindows contract.','Financial CAD measurements never infer materials or prices.','Default legacy DWGTakeoffEngine rejects arrays; production viewer/worker/review explicitly opt into the tested array contract.','500ms threshold is a measured shared-host interactive bound, not a promise for all hardware.','Capability dialog shows first200 entries explicitly, all source entities and Handle index remain intact.'],'failed_runs':['Full before chunked handoff: 7507 passed,1 failed,5 skipped; 100k event gap .539464 > .5; fixed without relaxing threshold.','A subsequent incomplete full run has no final Exit/JUnit and is not counted as PASS.','Actual converted DXF second-payment probe initially reproduced unsafe payment in a synthetic DB copy; lineage/history guard now rejects it.','Native Qt probe selectRow did not set current row; corrected probe uses a real viewport click, not a product workaround.','Host dotnet installer reported extraction chown errors; installed runtime/SDK binaries were checked and managed writer build exited0.'],'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in a.iterdir() if p.is_file()}}
(repo/'docs/acceptance/phase2_priority4_final_closure.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
text='''# بستن اولویت ۴ فاز ۲ StructuralPro

قرارداد ثابت: فقط معیارهای A تا G مالک، بدون ورود به اولویت۵ یا تغییر هشت فاز. داده‌ها مصنوعی و صریح‌اند؛ هیچ نقشه مصوب یا امضای واقعی مهندس معرفی نمی‌شوند.

## هویت نسخه

HEAD اولیه `7ebe8505ecffcc1b81995670ba2e576a3ce090e6`؛ PR18 فقط خواندنی `3434f63ee3718f6399bbf06bc8ca7a2c6a835b29`.
کد نهایی GitHub `'''+code+'''`، کاندید محلی آزموده `1524399cd6414729bd2bdd3721ff2b7b45b2dd26`؛ Tree دقیق `'''+tree+'''`.
Commit تحویل حاوی همین گزارش فقط شواهد است و SHA آن از Git قابل خواندن است؛ زیر‌درخت‌های اجرایی/آزمون با کد بالا برابرند. تفاوت SHA محلی و GitHub مربوط به metadata Commit است.

| معیار | وضعیت | شاهد |
|---|---|---|
'''
for k,d in gates.items():text+=f"|{k}|{d['status']}|{d['evidence']}|\n"
text+='''
## تغییرات و معماری حفظ‌شده

یک موتور و یک مسیر مالی: `DWG/DXF → DWGTakeoffEngine → DrawingTakeoffSession → StructuralProApp / ProjectStore → BOQ`.
Parsing و استخراج در subprocess قابل‌لغو QProcess اجرا می‌شود؛ Worker فاقد Qt/نوشتن پروژه است. نتیجه در فایل خصوصی والد تولید و در بسته‌های۱۰۰۰جزئی دریافت می‌شود؛ QGraphicsItemها فقط در رشته اصلی و بسته‌های۱۲۸جزئی ساخته می‌شوند. نقشه قبلی تا موفقیت کامل محفوظ است. درصد ساختگی وجود ندارد: مرحله تحلیل نامعین، سپس تعداد واقعی دریافت/ساخت نمایش داده می‌شود. لغو، تعویض منبع، خطای میانه Parsing و بستن Worker آزموده شدند. کنترل صفحه، نشست، Undo/Redo و BOQ هنگام بارگذاری مسدود است؛ شکست چیزی در SQLite نمی‌نویسد.

مدرک واحد JSON با policy `cad_unit_reference_v1` شامل SHA منبع، واحد، Handle طول مرجع، cad_length، real_length_m، author/reviewer مستقل و reference است؛ path/SHA مدرک در نشست و متره محفوظ است. ضرایب شناخته‌شده با Decimal برای تطبیق مدرک و داده source float با حد نسبی1e-12 کنترل می‌شوند. واحد معلوم فایل تغییر نمی‌کند؛ تعارض و فقدان مدرک Fail-Closed است. تغییر واحد روی متره قبلی ممنوع؛ نشست/اصلاحیه نسخه‌دار مستقل لازم است. حتی پیش‌نویس خالی واحد را پس از بازگشایی حفظ می‌کند.

MINSERT با هویت پایدار `Handle@row,column/child`، فاصله، دوران، Scale و آینه از همان ezdxf گسترش می‌یابد. چرخه، عمق/تعداد بیش از قرارداد، spacing نامعتبر، واحد متناقض Block و Z نامجاز رد می‌شوند. جمع والد از اجزای مالی مجاز و مستقل است؛ متن مقدار مالی ندارد. انتخاب والد تمام فرزندان قابل نمایش را Highlight می‌کند. پرداخت والد/فرزند هم در یک Batch و هم در سوابق، تغییر کد/عضو/Handle و استفاده دوباره از DXF تبدیل‌شده کنترل می‌شود. سوابق اصلی و اصلاحیه‌های اعمال‌شده در تطبیق منشأ استفاده می‌شوند؛ دفتر موازی، قیمت حدسی یا Schema جدید ساخته نشده است.

CIRCLE/ARC از شعاع و زاویه منبع محاسبه می‌شوند؛ رأس‌های کنترل برای نمایش/هویت‌اند و پاره‌خط جای طول تحلیلی نیست. برداشت تحلیلی و جمع Block از همان دفتر اصلاحیه موجود استفاده می‌کنند؛ اصل takeoff بازنویسی نمی‌شود، بازبینی مستقل و قفل مالی باقی است.

## آزمون‌های واقعی

'''
f=result['full'];text+=f"جامع نهایی: **{f['passed']} PASS / 0 FAIL / 0 ERROR / {f['skipped']} SKIP / Exit0**، مدت {f['duration_s']} ثانیه. پنج Skip فقط نبود PowerShell؛ دو هشدار قدیمی record_property/JUnit.\n"
text+='''
```bash
QT_QPA_PLATFORM=offscreen python -m pytest -q -ra --junitxml=/tmp/p4-close/phase2_priority4_closure_accepted.xml
python -m compileall -q core app tests
python -m pip check
git diff --check
```

هر سه بررسی تکمیلی Exit0 دارند. هدفمند مرحله handoff:۱۴۴ PASS؛ هدفمند نهایی منشأ:۱۴۲ PASS و سه مورد حجیم خارج از همان انتخاب، نه SKIP. شمارها هم‌پوشان‌اند و جمع نمی‌شوند. جامع شامل تمام تست‌های جدید، PDF و هندسه/سه سقف قبلی است. هیچ آزمون قدیمی حذف، تضعیف یا Skip اجباری نشد. JUnit و همه شکست‌ها/تلاش‌های میانی با طبقه‌بندی در شواهد باقی‌اند.

## کارایی و پاسخ‌گویی اندازه‌گیری‌شده

| Entity | کل بارگذاری، ثانیه | بیشترین فاصله event loop، میلی‌ثانیه | peak RSS KiB |
|---:|---:|---:|---:|
'''
for b in bench:text+=f"|{b['entities']}|{b['elapsed_s']:.3f}|{b['max_event_gap_s']*1000:.2f}|{b['peak_rss_kib']}|\n"
text+='''
سقف آزمونی۵۰۰ms با Timer ده‌میلی‌ثانیه‌ای، شامل شروع و پایان بارگذاری، روی میزبان مشترک تعریف شد؛ SLA عمومی نیست. شمار اجزا و طول مرجع `5×N m` در هر سه اندازه برابر است. اجرای جامع قدیمی یک وقفه۵۳۹ms نشان داد؛ آستانه کم نشد و handoff مدل به بسته‌های۱۰۰۰تایی تغییر کرد. پنج چرخه باز/بسته/خطای Parsing، صفر QProcess رهاشده و SQLite/BOQ ثابت دارند؛ RSS ثبت‌شده شامل cache/allocator است و اثبات فقدان هر نشت بلندمدت نیست.

## Oracle و جریان DWG واقعی

DWG باینری مصنوعی AC1032 با ACadSharp3.8.0.0 MIT و .NET8 واقعاً نوشته/خوانده شد. شش خط۳-۴-۵ در آرایه۲×۳ →۳۰m در BOQ؛ اصلاحیه آرایه۲×۴ →۴۰m، اختلاف+۱۰m. اصل takeoffها محفوظ، بستن/بازگشایی برابر، Integrity=ok و ثبت دوم اصلاحیه/CAS کهنه رد شدند. در Qt واقعی، Handle والد،۱۲ Graphic شامل متن/خط، فرم‌های native، بازبین مستقل مصنوعی و تأیید BOQ با کلیک آزموده شدند. DPI واقعی Qt با scale1 و1.5 همان۳۰m دارد؛ Windows تأیید نشده است.

Oracleهای خط۵m، دایره شعاع۲ با محیط/سطح4π، کمان۹۰درجه با طولπ، مربع کوچک در مختصات1e12، واحدهایm/mm/cm/in/ft و Transform آرایه با فرمول مستقل کنترل شدند. خطای جمع آرایه در چهار حالت Scale/آینه/دوران حداکثر حدود7.11e-15m است؛ حد نسبی1e-12 و مختصات مطلق1e-10m ثبت شده‌اند. منابع double هستند؛ ادعای دقت نامحدود یا Decimal مطلق CAD نداریم.

## ماتریس قرارداد Entity و فرمت

| نوع | قرارداد |
|---|---|
'''
for k,v in entities.items():text+=f'|{k}|{v}|\n'
text+='''
نسخه DWG آزموده فقط AC1032، DXF متنی R2018/AC1032 و decoder مشخص است. همه نسخه‌ها، Proxy اختصاصی، XREF حل‌نشده، فونت SHX ناموجود و Windows/Office طبق قرارداد مالک خارج از شرط بسته‌شدن‌اند. همه موارد خارج از مسیر مالی، علت مشخص و آزمون منفی دارند. نبود فونت اصلی با جایگزین سیستم و هشدار اعلام می‌شود؛ ابعاد متن وارد کمیت نمی‌شوند. گزارش قابلیت‌ها نخستین۲۰۰ Entity را آشکارا نشان می‌دهد؛ مدل کامل و Handle index حذف نمی‌شوند.

## Commitها و فایل‌ها

'''
for c,msg in commits:text+=f'- [{c[:8]}](https://github.com/Asanda021/StructuralPro-Recovery/commit/{c}) — {msg}\n'
text+='\n'+'\n'.join('- `'+p+'`' for p in files)+'\n'
if receipt:text+='\n## بازیابی مستقل\n\n'+json.dumps(receipt,ensure_ascii=False,indent=2)+'\n\nG بر اساس همین رسید واقعی تأیید شد. بکاپ اصلی کد آزموده و داده‌ها را نگه می‌دارد؛ بسته همراه، گزارش نهایی و Git bundle افزایشی Commit شواهد را نگه می‌دارد.\n'
else:text+='\n## بازیابی\n\nهنوز در این Snapshot تأیید نشده است؛ گزارش نهایی پس از بازدریافت و آزمون مستقل صادر می‌شود.\n'
text+='\nبدون Merge/Force Push/Actions دستی/EXE/Release؛ PR20 باید Open/Draft و PR18 بدون تغییر بماند. اولویت۵ آغاز نشده است.\n'
(repo/'docs/acceptance/phase2_priority4_final_closure.md').write_text(text)
print(json.dumps({'gates':{k:d['status'] for k,d in gates.items()},'full':f,'assets':len(result['artifact_sha256'])}))
