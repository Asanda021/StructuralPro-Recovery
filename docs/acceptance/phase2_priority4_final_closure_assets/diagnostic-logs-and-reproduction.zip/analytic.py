from pathlib import Path
p=Path('core/drawings/dwg_takeoff.py');s=p.read_text().replace('data.update(radius=r, length=2 * math.pi * r * sweep / 360)','data.update(radius=r, length=2 * math.pi * r * sweep / 360, start_angle=float(e.dxf.start_angle), sweep_angle=sweep)')
a=s.index('def cad_entity_geometry(');b=s.index('\ndef cad_review_digest',a)
s=s[:a]+'''def cad_entity_children(document,handle):
    found=[e for e in document.entities if e.handle==handle]
    if len(found)!=1:raise ValueError('Handle یکتا و معتبر لازم است')
    if found[0].entity_type!='INSERT':return found
    leaves=[e for e in document.entities if (e.handle.startswith(handle+'/') or e.handle.startswith(handle+'@')) and e.entity_type not in {'INSERT','TEXT','MTEXT'}]
    if not leaves:raise ValueError('بلوک فاقد هندسه قابل متره است؛ XREF حل‌نشده مجاز نیست')
    return leaves


def cad_entity_geometry(document,handle,metric,origin=(0,0)):
    """Source paths, analytic circles/arcs and disjoint sums, never display chords."""
    if cad_unit_factor(document.units) is None:raise ValueError('واحد CAD نامشخص است')
    found=[e for e in document.entities if e.handle==handle]
    if len(found)!=1:raise ValueError('Handle یکتا و معتبر لازم است')
    e=found[0];d=e.data
    for parent in document.entities:
        if parent.entity_type=='INSERT' and (handle==parent.handle or handle.startswith(parent.handle+'/') or handle.startswith(parent.handle+'@')) and parent.data.get('block_unit') not in {None,'unitless',document.units}:raise ValueError('واحد Block با سند ناسازگار است')
    if d.get('layer_visible') is False or d.get('layer_defined') is False:raise ValueError('جزء یا لایه پنهان و نامعتبر است')
    if e.entity_type=='INSERT':
        from decimal import Decimal
        parts=[cad_entity_geometry(document,c.handle,metric,origin) for c in cad_entity_children(document,handle)]
        return e,[p for _,points,_ in parts for p in points],float(sum((Decimal(str(q)) for _,_,q in parts),Decimal(0)))
    if d.get('unsupported_measurement'):raise ValueError(d['unsupported_measurement'])
    if metric not in {'length','area'} or d.get(metric,0)<=0:raise ValueError('متریک مثبت معتبر لازم است')
    curved=e.entity_type in {'CIRCLE','ARC'}
    if curved:
        if e.entity_type=='ARC' and metric=='area':raise ValueError('کمان باز سطح قابل پرداخت ندارد')
        x,y=d['center'];r=d['radius'];points=[(x,y),(x+r,y),(x,y+r)]
    elif e.entity_type=='LINE':points=[d['start'],d['end']]
    elif e.entity_type in {'POLYLINE','LWPOLYLINE'} and not any(d.get('bulges',[])):points=d['points']
    else:raise ValueError('نوع جزء یا منحنی bulge قرارداد مالی تأییدشده ندارد')
    if metric=='area' and not(curved or d.get('closed')):raise ValueError('سطح نیازمند حلقه بسته معتبر است')
    if metric=='length' and d.get('closed'):points=points+[points[0]]
    ox,oy=(float(v) for v in origin)
    if not all(math.isfinite(v) for v in (ox,oy)):raise ValueError('مبدأ نمایش نامعتبر است')
    result=[(float(x)-ox,oy-float(y)) for x,y in points]
    if curved and (result[0]==result[1] or result[0]==result[2]):raise ValueError('شعاع در تبدیل مختصات دقت کافی ندارد')
    return e,result,float(d[metric])


def cad_entity_claims(document,handle,metric):
    import json
    result=[]
    for e in cad_entity_children(document,handle):
        d=e.data
        if d.get('unsupported_measurement') or d.get('layer_visible') is False:raise ValueError('جزء بلوک فاقد قرارداد مجاز است')
        geometry={k:d[k] for k in ('start','end','points','closed','bulges','center','radius','start_angle','sweep_angle') if k in d}
        result.append({'handle':e.handle,'geometry_sha256':hashlib.sha256(json.dumps({'type':e.entity_type,'geometry':geometry,'metric':metric},sort_keys=True,separators=(',',':')).encode()).hexdigest()})
    return sorted(result,key=lambda x:x['handle'])

''' +s[b:]
s=s.replace("if e.layer!=meta.get('layer')", "if meta.get('entity_claims') is not None and meta['entity_claims']!=cad_entity_claims(document,meta['handle'],item.kind):raise ValueError('هویت اجزای CAD تغییر کرده است')\n    if e.layer!=meta.get('layer')")
s=s.replace('if item.kind=="area" and any(', 'if item.kind=="area" and meta.get("metric_contract")!="cad_analytic_v1" and any(')
s=s.replace('                    data.update(block=name,',"                    data['block_unit']=units_map.get(int(doc.blocks.get(name).block_record.dxf.get('units',0)), 'unknown')\n                    data.update(block=name,")
s=s.replace('                elif typ == "HATCH":', '''                elif typ == "DIMENSION":
                    data.update(text=str(e.dxf.get('text','<>')),insert=_xy(e.dxf.get('defpoint',(0,0))),height=1,rotation=0,font_notice='متن اندازه‌گذاری مرجع مستقل متره نیست')
                elif typ == "HATCH":''')
s=s.replace('                out.entities.append(DWGEntity(typ, layer, entity_handle, data))',"                if data.get('unsupported_measurement') and typ!='INSERT':out.warnings.append(data['unsupported_measurement'])\n                out.entities.append(DWGEntity(typ, layer, entity_handle, data))")
p.write_text(s)
p=Path('core/drawings/takeoff_session.py');s=p.read_text().replace('        meta.update(source_format=document.format',"        from core.drawings.dwg_takeoff import cad_entity_claims\n        meta.update(entity_claims=cad_entity_claims(document,handle,metric),source_path=str(Path(document.source).resolve()))\n        analytic=e.entity_type in {'INSERT','CIRCLE','ARC'}\n        if analytic:meta['metric_contract']='cad_analytic_v1'\n        meta.update(source_format=document.format")
s=s.replace("        if metric=='area':item=self.add_polygon", "        if analytic:\n            self._ensure_source_unique(kw['source']);self._record();ident=self._next_id()\n            item=TakeoffItem(ident,metric,amount,'m' if metric=='length' else 'm2',1,'',takeoff_code,kw['source'],self._source_ref(1,ident),tuple(points),'CAD analytic source metric; circle/arc IEEE754 and disjoint child sum; rel tolerance 1e-12',cad_evidence=meta)\n            self.items.append(item);self._commit()\n        elif metric=='area':item=self.add_polygon")
p.write_text(s)
p=Path('core/drawings/takeoff_bridge.py');s=p.read_text().replace("identity.update(geometry=canonical(model_points,row['kind']=='area'),operation='cad:'+row['kind'],measurement_context=cad['handle'])", "identity.update(geometry=canonical(model_points,row['kind']=='area') if cad.get('metric_contract')!='cad_analytic_v1' else model_points,operation='cad:'+row['kind'],measurement_context=cad['handle'])")
s=s.replace('                if item.kind == "area" and item.geometry_evidence is not None:',"                if (item.cad_evidence or {}).get('metric_contract')=='cad_analytic_v1':\n                    from core.drawings.dwg_takeoff import DWGTakeoffEngine,verify_cad_item\n                    verify_cad_item(item,DWGTakeoffEngine.with_array_support().import_file(session.drawing_source),require_review=False)\n                    continue\n                if item.kind == \"area\" and item.geometry_evidence is not None:")
s=s.replace("if row['kind']=='area':\n            meta=row.get('geometry_evidence')","if row['kind']=='area' and (cad or {}).get('metric_contract')!='cad_analytic_v1':\n            meta=row.get('geometry_evidence')")
s=s.replace("if old.get('domain')=='drawing' and old.get('item')=='area':", "if old.get('domain')=='drawing' and old.get('item')=='area' and (p.get('cad_evidence') or {}).get('metric_contract')!='cad_analytic_v1':")
s=s.replace("                if other and old.get('item')==row['kind']", "                if other and old.get('item')==row['kind'] and (other.get('source_sha256')==cad.get('source_sha256') or other.get('source_path')==cad.get('source_path') and cad.get('source_path')):\n                    oldclaims=other.get('entity_claims') or [{'handle':other.get('handle')}]\n                    newclaims=cad.get('entity_claims') or [{'handle':cad.get('handle')}]\n                    if {x['handle'] for x in oldclaims}&{x['handle'] for x in newclaims} or {x.get('geometry_sha256') for x in oldclaims if x.get('geometry_sha256')}&{x.get('geometry_sha256') for x in newclaims if x.get('geometry_sha256')}:raise ValueError('والد/فرزند یا هندسه CAD قبلاً پرداخت شده است')\n                if other and old.get('item')==row['kind']",1)
p.write_text(s)
