from pathlib import Path
p=Path('app/graphical_takeoff.py');s=p.read_text().replace('QVariantAnimation, QEasingCurve','QVariantAnimation, QEasingCurve, QProcess, QTimer')
s=s.replace('self.session = DrawingTakeoffSession(pdf_path)','self.cad_loading=False\n        self._cad_job=None\n        self.session = DrawingTakeoffSession(pdf_path)',1)
s=s.replace('self.cad_measure=QPushButton',"self.cad_cancel=QPushButton('لغو بارگذاری CAD');self.cad_cancel.clicked.connect(self.cancel_cad_loading)\n        self.cad_measure=QPushButton",1)
s=s.replace('self.cad_metric,self.cad_measure,self.cad_review):','self.cad_metric,self.cad_measure,self.cad_review,self.cad_cancel):')
s=s.replace('self.open_drawing(path)\n        except',"self.open_cad_async(path) if Path(path).suffix.lower() in {'.dwg','.dxf'} else self.open_drawing(path)\n        except",1)
s=s.replace('self.open_drawing(pdf_path)\n            except',"self.open_cad_async(pdf_path) if Path(pdf_path).suffix.lower() in {'.dxf','.dwg'} and Path(pdf_path).stat().st_size>512_000 else self.open_drawing(pdf_path)\n            except",1)
s=s.replace('    def open_drawing(self, path):\n','    def open_drawing(self, path):\n        self.cancel_cad_loading()\n',1)
s=s.replace('    def _render_cad(self):\n','    def _render_cad(self):\n        for _ in self._render_cad_steps():pass\n\n    def _render_cad_steps(self):\n')
s=s.replace('        coords=[]\n        for entity in doc.entities:',"        coords=[]\n        for entity in ([] if hasattr(doc,'_render_bounds') else doc.entities):",1)
s=s.replace('        if not coords:\n',"        if not coords and not hasattr(doc,'_render_bounds'):\n",1)
s=s.replace('        min_x=min(x for x,_ in coords); max_x=max(x for x,_ in coords)\n        min_y=min(y for _,y in coords); max_y=max(y for _,y in coords)',"        min_x,max_x,min_y,max_y=doc._render_bounds if hasattr(doc,'_render_bounds') else (min(x for x,_ in coords),max(x for x,_ in coords),min(y for _,y in coords),max(y for _,y in coords))")
s=s.replace('        for entity in doc.entities:\n            item=None', '        for entity_index,entity in enumerate(doc.entities):\n            if entity_index%128==0:yield entity_index\n            item=None',1)
for fn in ['save_session_to_project','commit_selected_to_boq','measure_cad_selection','review_cad_selection']:
 marker='    def '+fn+'(self):\n';s=s.replace(marker,marker+"        if self.cad_loading:self.status.setText('بارگذاری CAD هنوز کامل نشده است؛ متره و BOQ مسدودند');return False\n",1)
index=s.index('    def beam_drawing_context(self):')
new='''    def _cad_busy(self, busy):
        self.cad_loading=busy
        if busy:
            self._cad_enabled={c:c.isEnabled() for c in self.findChildren(QWidget) if isinstance(c,(QPushButton,QComboBox,QLineEdit))}
            for c in self._cad_enabled:c.setEnabled(c in (self.open_pdf,self.cad_cancel))
            self.canvas.setEnabled(False);self.cad_controls.show()
        else:
            for c,v in getattr(self,'_cad_enabled',{}).items():c.setEnabled(v)
            self.canvas.setEnabled(True)

    def cancel_cad_loading(self):
        job=self._cad_job
        if not job:return
        self._cad_job=None;p=job['process'];p.blockSignals(True)
        if p.state()!=QProcess.ProcessState.NotRunning:p.kill();p.waitForFinished(1000)
        if job.get('old'):
            self.cad_document,self.canvas.scene,self._cad_items,self._cad_handle_items,self._cad_scene_origin=job['old'];job['scene'].deleteLater()
        self.cad_layers.clear()
        for label,value in job['layers']:self.cad_layers.addItem(label,value)
        self.cad_layers.setCurrentIndex(job['layer_index'])
        job['temp'].cleanup();p.deleteLater();self._cad_busy(False);self.cad_controls.setVisible(self.viewer.kind=='cad');self.status.setText('بارگذاری CAD لغو شد؛ نقشه و متره قبلی محفوظ است')

    def open_cad_async(self,path):
        import tempfile,sys
        self.cancel_cad_loading()
        if self.session.items and str(path)!=self.session.drawing_source:
            if QMessageBox.question(self,'تغییر نقشه','نشست دارای متره است؛ پیش از تغییر، ذخیره را بررسی کنید. ادامه؟',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        p=QProcess(self);temp=tempfile.TemporaryDirectory(prefix='structuralpro-cad-')
        job={'process':p,'temp':temp,'result':str(Path(temp.name)/'result'),'old':None,'layers':[(self.cad_layers.itemText(i),self.cad_layers.itemData(i)) for i in range(self.cad_layers.count())],'layer_index':self.cad_layers.currentIndex()}
        self._cad_job=job;self._cad_busy(True);self.status.setText('در حال تحلیل CAD در پردازش مستقل؛ لغو فعال است')
        def failed(message):
            if self._cad_job is not job:return
            self.cancel_cad_loading();self.status.setText('خطای بارگذاری CAD؛ نقشه قبلی محفوظ است: '+message)
        def parsed(code,status):
            if self._cad_job is not job:return
            if code!=0:failed(bytes(p.readAllStandardError()).decode('utf-8','replace')[-1500:]);return
            try:
                import pickle
                # Private file written by our own child; never a user-imported pickle.
                with open(job['result'],'rb') as f:doc=pickle.load(f)
                job['old']=(self.cad_document,self.canvas.scene,self._cad_items,self._cad_handle_items,self._cad_scene_origin)
                scene=QGraphicsScene(self);scene.setItemIndexMethod(QGraphicsScene.ItemIndexMethod.NoIndex);job['scene']=scene
                self.cad_document=doc;self.canvas.scene=scene;job['steps']=self._render_cad_steps();QTimer.singleShot(0,batch)
            except Exception as exc:failed(str(exc))
        def batch():
            if self._cad_job is not job:return
            try:
                n=next(job['steps']);self.status.setText(f'ساخت نمایش CAD: {n} از {len(self.cad_document.entities)} جزء؛ متره مسدود است');QTimer.singleShot(0,batch)
            except StopIteration:
                if self.engine is not None:self.engine.close()
                self.engine=None;self.pdf_path=str(path)
                if self.session.drawing_source!=str(path):self.session=DrawingTakeoffSession(str(path));self.canvas.session=self.session;self.persisted_session_id=None;self.persisted_session_revision=None
                self.viewer.path=Path(path);self.viewer.kind='cad';self.viewer.page_count=1;self.viewer.current_page=1;self.viewer.cad_document=self.cad_document
                self.page=1;self.canvas.read_only_model=False;self.canvas.setScene(job['scene']);job['old'][1].deleteLater()
                self._cad_job=None;temp.cleanup();p.deleteLater();self._cad_busy(False);self.source_label.setText('منبع CAD: '+Path(path).name);self.refresh();self.reset_zoom();self.status.setText(f'CAD آماده است؛ {len(self.cad_document.entities)} جزء حفظ شد؛ واحد: {self.cad_document.units}')
            except Exception as exc:failed(str(exc))
        p.finished.connect(parsed);p.errorOccurred.connect(lambda error:failed(p.errorString()));p.setWorkingDirectory(str(Path(__file__).resolve().parents[1]));p.start(sys.executable,['-m','core.drawings.cad_import_worker',str(Path(path).resolve()),job['result']])

    def closeEvent(self,event):
        self.cancel_cad_loading()
        if self.engine is not None:self.engine.close()
        super().closeEvent(event)

'''
s=s[:index]+new+s[index:];p.write_text(s)
