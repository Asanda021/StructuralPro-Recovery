from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('/tmp/p4-close');b=root/'backup-code';b.mkdir(exist_ok=True)
def cp(p,name):
 p=Path(p);dest=b/name
 if p.is_dir():shutil.copytree(p,dest,dirs_exist_ok=True)
 else:dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
cp(root/'StructuralPro_P4_closure_code.bundle','StructuralPro_P4_closure_code.bundle')
for name in ['real-dwg-final','derived-green','ui-final-100','ui-final-150','transform-oracle','stress','mixed-final','converted-artifacts','writer','writer-bin']:
 if (root/name).exists():cp(root/name,name)
for p in root.iterdir():
 if p.is_file() and p.suffix in {'.log','.xml','.exit','.py'}:cp(p,'evidence/'+p.name)
cp(root/'prior/converter','converter')
# Keep only final representative large fixtures/evidence, not every repeated pytest tree.
for folder in (root/'accepted-performance').glob('test_async_responsiveness*'):
 if folder.name.endswith('current'):continue
 cp(folder,'large-fixtures/'+folder.name)
repo=Path('/workspace/scratch/61dce18379e6/p4-closure')
for name in ['phase2_priority4_final_closure.md','phase2_priority4_final_closure.json','phase2_priority4_final_closure_assets']:
 cp(repo/'docs/acceptance'/name,'reports/'+name)
(b/'README.txt').write_text('Synthetic CAD acceptance, not an approved design. Code head f0bf3eec998d391ddaf62c81f827f73c9d7913dc; tested local commit1524399cd6414729bd2bdd3721ff2b7b45b2dd26; equal code tree7912f377e3d7129f5b247f49a492161b6e91c0f5. .NET8 host runtime and Python requirements needed; managed ACadSharp3.8.0.0 MIT converter/writer, no Windows EXE. Installer ownership warning is environmental. No source evidence path or signed metadata may be rewritten; map archived roots only at evidence read I/O. Independent probes create fresh sample projects with fresh real reviewed source bytes. Reports in this primary snapshot precede restore verification; final complete report and evidence-only incremental Git bundle are in companion archive.\n')
m={'code_head':'f0bf3eec998d391ddaf62c81f827f73c9d7913dc','tested_tree':'7912f377e3d7129f5b247f49a492161b6e91c0f5','path_mappings':{'/tmp/p4-close':'archive root','/workspace/scratch/61dce18379e6/p4-closure':'restored Git checkout'},'files':{str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in b.rglob('*') if p.is_file()}}
(b/'Manifest.json').write_text(json.dumps(m,indent=2))
z=root/'StructuralPro_P4_Closure_f0bf3eec_20261021.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for p in b.rglob('*'):
  if p.is_file():f.write(p,str(p.relative_to(b)))
print(json.dumps({'path':str(z),'sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'bytes':z.stat().st_size,'files':len(m['files'])}))
