import json,hashlib
from pathlib import Path
import ezdxf
out=Path('/tmp/p5-ifc/final-scenario');doc=json.loads((out/'ifc-document.json').read_text());beam=next(e for e in doc['elements'] if e['ifc_type']=='IfcBeam' and e['origin_m'][2]=='0.00')
m=ezdxf.new('R2018');m.units=6
line=m.modelspace().add_line((1000000,5),(1000000,9));m.modelspace().add_text('Synthetic IFC companion - unreviewed',dxfattribs={'height':.2,'insert':(1000001,7)})
p=out/'companion.dxf';m.saveas(p)
proposal={'status':'unreviewed_fixture_reference','financial_approval':False,'ifc_sha256':doc['source_sha256'],'ifc_global_id':beam['global_id'],'ifc_revision':'R1','drawing_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'drawing_revision':'synthetic-R1','cad_handle':line.dxf.handle,'units':'m','reference_endpoints_m':[[1000000,5],[1000000,9]],'analytic_length_m':'4','coordinate_mapping':'explicit synthetic local XY to CAD identity; z=0 only','limitation':'Not a persisted approved crosswalk; no bidirectional UI or financial permission is claimed'}
(out/'unreviewed-2d-reference.json').write_text(json.dumps(proposal,indent=2))
