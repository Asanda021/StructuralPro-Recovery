"""Artificial repeated geometry benchmark; no independent payable ownership."""
import sys,time,json,runpy,resource
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
ns=runpy.run_path('tests/test_phase2_priority5_ifc.py')
import ifcopenshell
from core.drawings.bim_adapter import BIMAdapter
from app.graphical_takeoff import GraphicalTakeoffDialog
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
app=QApplication.instance() or QApplication([]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);results=[]
for n in (100,1000):
 p=out/f'{n}.ifc';m,objects=ns['model_file'](p);base=objects[0];st=m.by_type('IfcBuildingStorey')[0]
 for i in range(n-12):
  obj=m.create_entity('IfcBeam',GlobalId=ifcopenshell.guid.new(),Name=f'Benchmark {i}',ObjectPlacement=base.ObjectPlacement,Representation=base.Representation)
  m.create_entity('IfcRelContainedInSpatialStructure',GlobalId=ifcopenshell.guid.new(),RelatedElements=[obj],RelatingStructure=st)
 m.write(str(p));start=time.monotonic();d=BIMAdapter().read_document(p,revision='benchmark');read_s=time.monotonic()-start
 w=GraphicalTakeoffDialog();w.show();ticks=[];timer=QTimer();timer.timeout.connect(lambda:ticks.append(time.monotonic()));timer.start(10);QTest.qWait(30)
 ticks.append(time.monotonic());start=time.monotonic();w.open_cad_async(str(p))
 while w.cad_loading:QTest.qWait(10)
 load_s=time.monotonic()-start;ticks.append(time.monotonic());QTest.qWait(30);timer.stop()
 row={'elements':n,'source_bytes':p.stat().st_size,'engineering_read_s':read_s,'gui_open_s':load_s,'mesh_count':len(w.viewer.ifc_document.meshes),'max_event_gap_s':max(b-a for a,b in zip(ticks,ticks[1:])),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'event_timestamps':ticks,'threshold_s':.5,'threshold_reason':'Existing P4 coarse 500ms bound on this Linux host; not a Windows SLA','display_path':'existing isolated worker + bounded mesh-path batches','payable_geometry':False}
 row['responsiveness_pass']=row['max_event_gap_s']<.5
 results.append(row);w.close()
(out/'benchmark.json').write_text(json.dumps(results,indent=2));print(json.dumps(results))
