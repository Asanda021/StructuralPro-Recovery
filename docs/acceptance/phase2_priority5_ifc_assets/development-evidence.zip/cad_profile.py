import sys,time,gc,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from app.graphical_takeoff import GraphicalTakeoffDialog
p=Path('/tmp/pytest-of-root/pytest-24/test_async_responsiveness_and_2/100000.dxf')
app=QApplication([]);w=GraphicalTakeoffDialog();w.show();ticks=[];collections=[]
def g(phase,info):collections.append((time.monotonic(),phase,info['generation']))
gc.callbacks.append(g)
timer=QTimer();timer.timeout.connect(lambda:ticks.append((time.monotonic(),w.status.text())));timer.start(10);ticks.append((time.monotonic(),'start'));start=time.monotonic();w.open_cad_async(str(p))
while w.cad_loading:QTest.qWait(10)
QTest.qWait(100);ticks.append((time.monotonic(),'end'));timer.stop();w.close();gc.callbacks.remove(g)
gaps=sorted([(b[0]-a[0],a,b) for a,b in zip(ticks,ticks[1:])],reverse=True)[:10]
result={'elapsed':time.monotonic()-start,'top_gaps':gaps,'gc':collections};Path('/tmp/p5-ifc/cad-profile.json').write_text(json.dumps(result,ensure_ascii=False));print(json.dumps({'elapsed':result['elapsed'],'top_gaps':gaps[:5],'long_gc':[(collections[i+1][0]-v[0],v) for i,v in enumerate(collections[:-1]) if v[1]=='start' and collections[i+1][1]=='stop' and collections[i+1][0]-v[0]>.05]},ensure_ascii=False))
