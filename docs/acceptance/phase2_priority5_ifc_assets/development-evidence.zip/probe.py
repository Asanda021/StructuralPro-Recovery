"""Replay actual IFC/Qt/SQLite evidence without treating fixtures as design approval."""
import sys,runpy,json,time,hashlib,resource
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
ns=runpy.run_path('tests/test_phase2_priority5_ifc.py')
from PySide6.QtWidgets import QApplication
from core.drawings.bim_adapter import BIMAdapter
from core.platform.application import StructuralProApp
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
app=QApplication.instance() or QApplication([])
ns['test_qt_ifc_inspector_real_selection_filter_and_proposal'](out)
path=out/'model.ifc';doc=BIMAdapter().read_document(path,revision='R1')
(out/'ifc-document.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2))
service=StructuralProApp(out/'app');project=service.open_project('P')
receipt={'source_sha256':doc['source_sha256'],'schema':doc['schema'],'parser':doc['parser'],'elements':len(doc['elements']),'storeys':len(doc['storeys']),
         'oracle_origin_m':['1000000','7','0'],'first_beam_origin_m':next(e['origin_m'] for e in doc['elements'] if e['ifc_type']=='IfcBeam' and e['origin_m'][2]=='0.00'),
         'explicit_qto_values_m':sorted(set(q['value_si'] for e in doc['elements'] for q in e['quantities'])),
         'identity_proposals':len(project['ifc_identity_proposals']),'proposal_status':project['ifc_identity_proposals'][0]['status'],
         'boq_rows':len(project.get('boq',[])),'integrity':service.store.integrity_check(),'financial_path':'BLOCKED pending implementation of reviewed identity/crosswalk/IFC BOQ bridge'}
(out/'scenario.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));service.store.close()
print(json.dumps(receipt,ensure_ascii=False))
