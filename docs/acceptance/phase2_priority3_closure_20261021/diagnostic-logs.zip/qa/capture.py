import sys,json
sys.path.insert(0,'/workspace/scratch/61dce18379e6/p3-final')
from PySide6.QtWidgets import QApplication,QInputDialog,QDialogButtonBox
from PySide6.QtCore import Qt,QTimer
from PySide6.QtTest import QTest
from core.platform.application import StructuralProApp
from app.graphical_takeoff import GraphicalTakeoffDialog
q=QApplication([]);root='/tmp/p3-close/scenario-final';service=StructuralProApp(root+'/db');p=service.open_project('P');sid=next(iter(p['drawing_sessions']))
d=GraphicalTakeoffDialog(pdf_path=root+'/synthetic-two-revision-pages.pdf',app_service=service,project_id='P');d.resize(1500,1100);d.show();q.processEvents()
def fill():
 w=q.activeModalWidget();assert isinstance(w,QInputDialog);w.setTextValue(sid);QTest.mouseClick(w.findChild(QDialogButtonBox).button(QDialogButtonBox.Ok),Qt.LeftButton)
QTimer.singleShot(50,fill);QTest.mouseClick(d.load_session_button,Qt.LeftButton);q.processEvents()
QTest.mouseClick(d.table.viewport(),Qt.LeftButton,pos=d.table.visualItemRect(d.table.item(0,0)).center());q.processEvents();d.grab().save(root+'/multipart-reopened.png')
d.geometry_components.setFocus();QTest.keyClick(d.geometry_components,Qt.Key_Down);q.processEvents();d.grab().save(root+'/component-highlight.png');d.close();service.store.close()
