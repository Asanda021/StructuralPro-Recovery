import sys,json
from pathlib import Path
sys.path[:0]=['/workspace/scratch/61dce18379e6/p3-final','/workspace/scratch/61dce18379e6/p3-final/tests']
from core.platform.application import StructuralProApp
from test_phase2_planar_roof import bound_planar
from scripts.phase2_priority3_closure_probe import verify_reports
root=Path('/tmp/p3-close/three-roof-reports');result={}
for kind in ['solid_slab','joist_block','joist_foam']:
 path=root/kind;path.mkdir(parents=True,exist_ok=True)
 app,s,i,rec,d=bound_planar(path,kind)
 app.save_aec_system_draft('P',d,expected_revision=0);app.review_roof_system('P',kind,'L1','S1',expected_revision=1,reviewer='independent synthetic report checker',note='independent analytic L-shape quantities');app.commit_aec_system('P',kind,'L1','S1',expected_revision=2)
 for fmt in ['pdf','xlsx','docx','csv']:app.export_roof_detail_report('P',kind,'L1','S1',path/('effective-roof.'+fmt),format=fmt)
 rows=app.open_project('P')['takeoffs'];result[kind]=verify_reports(path,rows);app.store.close()
(root/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
