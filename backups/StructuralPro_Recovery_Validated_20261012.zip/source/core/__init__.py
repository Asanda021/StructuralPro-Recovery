"""StructuralPro core package."""
